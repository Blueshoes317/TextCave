import java.util.Scanner;
public class TextCave {
	
	/* 
	 * WELCOME TO TEXTCAVE!
	 * 
	 * A classic text adventure - rebooted
	 * 
	 * By Blueshoes317
	 * 
	 * NOTE: ASTERISKS IN TEXT DENOTE COMMANDS (like *this*)
	 * 
	 * DEVELOPMENT TIMELINE:
	 * 
	 * ALPHA DEVELOPMENT:
	 * 
	 * VERSION 0.12:
	 * 
	 * 3-13-19
	 * Added basic equipment, introductory story, health
	 * 
	 * 3-14-19
	 * Improved equipment system, added food/water, added storyline elements as far as the end of the dummy training, added fighting system
	 * Found 'first entry both print' bug
	 * Found solution to 'first entry both print' bug: 
	 * adds nested if with base: (if input is already present){}(else if input is second command){second} thus bypassing second statement if there was a first executed
	 * 
	 * 3-15-19
	 * Found new bug with previous update:
	 * Second statement ignored if used
	 * 2nd statement ignore fixed
	 * New bug with fix: Second statement executed if answer is not a valid command
	 * Fixed new bug, first entry both print bug is back
	 * Fixed all input bugs
	 * Added storyline to as far as slime defeat
	 * Found multiple option 2nd wrong select bug
	 * Found dodge jump bug
	 * 
	 * 3-16-19
	 * Added storyline to mid Дpyг fight
	 * Improved fighting system
	 * 
	 * 3-18-19
	 * Added mobility, attack multiplier
	 * Improved fighting system to let fights be longer, finished Дpyг fight
	 * 
	 * 3-19/20-19
	 * FIXED ALL LOGICAL BUGS!!!
	 * Game is now bug-free, resumed work on storyline
	 * Started work on Giant Bat fight
	 * Finished Giant Bat fight, using many similar mechanics to Дpyг
	 * Began formulating first stage boss/final boss of 0.12
	 * 
	 * 3-21-19
	 * Finished King Slime fight, released version 0.12
	 * 
	 * VERSION  0.12.1
	 * 3-21-19
	 * Fixed small Slime left - jump bug
	 * Fixed bat turn bug
	 * Fixed Дpyг player invincibility bug
	 * Fixed Дpyг unending fight bug
	 * All known major bugs fixed
	 * 
	 * VERSION 0.12.2
	 * 3-22-19
	 * Fixed numerous comprehension errors, made text easier to discern
	 * 
	 * VERSION 0.12.3
	 * 3-22-19
	 * Made King Slime more difficult due to popular demand
	 * FIXED GUT LEFT-JUMP SMALL SLIME BUG, was result of nonexclusive if-else statement conditionals
	 * Fixed grammatical errors throughout code
	 * 
	 * VERSION 0.19
	 * 3-23/24-19
	 * Got base of underwater cave done, mostly busy work left to complete it, did block id 124 as proof of concept
	 * 
	 * 3-25-19
     * Finished underwater stage up to block id 14, file size doubled from before start of underwater level
     * 
     * 3-27-19
     * Finished up to block id 21, hit 100kb file size
     * 
     * 3-30-19
     * Over several days got to block id 43, changed map to work better
     * 
     * 4-2-19
     * After a brief hiatus, got to block id 50, changed breath capacity to 12, realized there was a lot of marginal situations, makes map easier as well
     *
     * 4-4-19
     * Finished to block id 59
     * 
     * 4-5-19
     * Block id 69 passed, "//nice" spam ensues
     * Finished to block id 73, file size now at 200kb
     * 
     * 4-7-19
     * Streamlined "Press Enter to continue", freed up ~20 inputs
     * Finished to block id 100
     * 
     * 4-8-19
     * FINISHED UNDERWATER STAGE, moving to testing
     * Testing returned positive results, 0.19 released
     *
	 */
	
	
	private static Scanner Direction1check = new Scanner(System.in);
	private static Scanner Direction2check = new Scanner(System.in);
	private static Scanner Direction3check = new Scanner(System.in);
	private static Scanner Direction4check = new Scanner(System.in);
	private static Scanner Direction5check = new Scanner(System.in);
	private static Scanner Direction6check = new Scanner(System.in);
	private static Scanner Direction7check = new Scanner(System.in);
	private static Scanner Direction8check = new Scanner(System.in);
	private static Scanner Direction9check = new Scanner(System.in);
	private static Scanner Direction10check = new Scanner(System.in);
	private static Scanner Direction11check = new Scanner(System.in);
	private static Scanner Direction12check = new Scanner(System.in);
	private static Scanner Direction13check = new Scanner(System.in);
	private static Scanner Direction14check = new Scanner(System.in);
	private static Scanner Direction15check = new Scanner(System.in);
	private static Scanner Direction16check = new Scanner(System.in);
	private static Scanner Direction17check = new Scanner(System.in);
	private static Scanner Direction18check = new Scanner(System.in);
	private static Scanner Direction19check = new Scanner(System.in);
	private static Scanner Direction20check = new Scanner(System.in);
	private static Scanner Direction21check = new Scanner(System.in);
	private static Scanner Direction22check = new Scanner(System.in);
	private static Scanner Direction23check = new Scanner(System.in);
	private static Scanner Direction24check = new Scanner(System.in);
	private static Scanner Direction25check = new Scanner(System.in);
	private static Scanner Direction26check = new Scanner(System.in);
	private static Scanner Direction27check = new Scanner(System.in);
	private static Scanner Direction28check = new Scanner(System.in);
	private static Scanner Direction29check = new Scanner(System.in);
	private static Scanner Direction30check = new Scanner(System.in);
	private static Scanner Direction31check = new Scanner(System.in);
	private static Scanner Direction32check = new Scanner(System.in);
	private static Scanner Direction33check = new Scanner(System.in);
	private static Scanner Direction34check = new Scanner(System.in);
	private static Scanner Direction35check = new Scanner(System.in);
	private static Scanner Direction36check = new Scanner(System.in);
	private static Scanner Direction37check = new Scanner(System.in);
	private static Scanner Direction38check = new Scanner(System.in);
	private static Scanner Direction39check = new Scanner(System.in);
	private static Scanner Direction40check = new Scanner(System.in);
	private static Scanner Direction41check = new Scanner(System.in);
	private static Scanner Direction42check = new Scanner(System.in);
	private static Scanner Direction43check = new Scanner(System.in);
	private static Scanner Direction44check = new Scanner(System.in);
	private static Scanner Direction45check = new Scanner(System.in);
	private static Scanner Direction46check = new Scanner(System.in);
	private static Scanner Direction47check = new Scanner(System.in);
	private static Scanner Direction48check = new Scanner(System.in);
	private static Scanner Direction49check = new Scanner(System.in);
	private static Scanner Direction50check = new Scanner(System.in);
	private static Scanner Direction51check = new Scanner(System.in);
	private static Scanner Direction52check = new Scanner(System.in);
	private static Scanner Direction53check = new Scanner(System.in);
	private static Scanner Direction54check = new Scanner(System.in);
	private static Scanner Direction55check = new Scanner(System.in);
	private static Scanner Direction56check = new Scanner(System.in);
	private static Scanner Direction57check = new Scanner(System.in);
	private static Scanner Direction58check = new Scanner(System.in);
	private static Scanner Direction59check = new Scanner(System.in);
	private static Scanner Direction60check = new Scanner(System.in);
	private static Scanner Direction61check = new Scanner(System.in);
	private static Scanner Direction62check = new Scanner(System.in);
	private static Scanner Direction63check = new Scanner(System.in);
	private static Scanner Direction64check = new Scanner(System.in);
	private static Scanner Direction65check = new Scanner(System.in);
	private static Scanner Direction66check = new Scanner(System.in);
	private static Scanner Direction67check = new Scanner(System.in);
	private static Scanner Direction68check = new Scanner(System.in);
	private static Scanner Direction69check = new Scanner(System.in);
	private static Scanner Direction70check = new Scanner(System.in);
	private static Scanner Direction71check = new Scanner(System.in);
	private static Scanner Direction72check = new Scanner(System.in);
	private static Scanner Direction73check = new Scanner(System.in);
	private static Scanner Direction74check = new Scanner(System.in);
	private static Scanner Direction75check = new Scanner(System.in);
	private static Scanner Direction76check = new Scanner(System.in);
	private static Scanner Direction77check = new Scanner(System.in);
	private static Scanner Direction78check = new Scanner(System.in);
	private static Scanner Direction79check = new Scanner(System.in);
	private static Scanner Direction80check = new Scanner(System.in);
	private static Scanner Direction81check = new Scanner(System.in);
	private static Scanner Direction82check = new Scanner(System.in);
	private static Scanner Direction83check = new Scanner(System.in);
	private static Scanner Direction84check = new Scanner(System.in);
	private static Scanner Direction86check = new Scanner(System.in);
	private static Scanner Direction87check = new Scanner(System.in);
	private static Scanner Direction88check = new Scanner(System.in);
	private static Scanner Direction89check = new Scanner(System.in);
	private static Scanner Direction90check = new Scanner(System.in);
	private static Scanner Direction91check = new Scanner(System.in);
	private static Scanner Direction92check = new Scanner(System.in);
	private static Scanner Direction93check = new Scanner(System.in);
	private static Scanner Direction94check = new Scanner(System.in);
	private static Scanner Direction95check = new Scanner(System.in);
	private static Scanner Direction96check = new Scanner(System.in);
	private static Scanner Direction97check = new Scanner(System.in);
	private static Scanner Direction98check = new Scanner(System.in);
	private static Scanner Direction99check = new Scanner(System.in);
	private static Scanner Direction100check = new Scanner(System.in);
	private static Scanner Direction101check = new Scanner(System.in);
	private static Scanner Direction102check = new Scanner(System.in);
	private static Scanner Direction103check = new Scanner(System.in);
	private static Scanner Direction104check = new Scanner(System.in);
	private static Scanner Direction105check = new Scanner(System.in);
	private static Scanner Direction106check = new Scanner(System.in);
	private static Scanner Direction107check = new Scanner(System.in);
	private static Scanner Direction108check = new Scanner(System.in);
	private static Scanner Direction109check = new Scanner(System.in);
	private static Scanner Direction110check = new Scanner(System.in);
	private static Scanner Direction111check = new Scanner(System.in);
	private static Scanner Direction112check = new Scanner(System.in);
	private static Scanner Direction113check = new Scanner(System.in);
	private static Scanner Direction114check = new Scanner(System.in);
	private static Scanner Direction115check = new Scanner(System.in);
	private static Scanner Direction116check = new Scanner(System.in);
	private static Scanner Direction117check = new Scanner(System.in);
	private static Scanner Direction118check = new Scanner(System.in);
	private static Scanner Direction119check = new Scanner(System.in);
	private static Scanner Direction120check = new Scanner(System.in);
	private static Scanner Direction121check = new Scanner(System.in);
	private static Scanner Direction122check = new Scanner(System.in);
	private static Scanner Direction123check = new Scanner(System.in);
	private static Scanner Direction124check = new Scanner(System.in);
	private static Scanner Direction125check = new Scanner(System.in);
	private static Scanner Direction126check = new Scanner(System.in);
	private static Scanner Direction127check = new Scanner(System.in);
	private static Scanner Direction128check = new Scanner(System.in);
	private static Scanner Direction129check = new Scanner(System.in);
	private static Scanner Direction130check = new Scanner(System.in);
	private static Scanner Direction131check = new Scanner(System.in);
	private static Scanner Direction132check = new Scanner(System.in);
	private static Scanner Continue1check = new Scanner(System.in);
	private static Scanner Continue2check = new Scanner(System.in);
	private static Scanner Continue3check = new Scanner(System.in);
	private static Scanner Continue4check = new Scanner(System.in);
	private static Scanner Continue5check = new Scanner(System.in);
	private static Scanner Continue6check = new Scanner(System.in);
	private static Scanner Continue7check = new Scanner(System.in);
	private static Scanner Continue8check = new Scanner(System.in);
	private static Scanner Continue9check = new Scanner(System.in);
	private static Scanner Continue10check = new Scanner(System.in);
	private static Scanner Continue11check = new Scanner(System.in);
	private static Scanner Continue12check = new Scanner(System.in);
	private static Scanner Continue13check = new Scanner(System.in);
	private static Scanner Continue14check = new Scanner(System.in);
	private static Scanner Continue15check = new Scanner(System.in);
	private static Scanner Action1check = new Scanner(System.in);
	private static Scanner Action2check = new Scanner(System.in);
	private static Scanner Action3check = new Scanner(System.in);
	private static Scanner Action4check = new Scanner(System.in);
	private static Scanner Action5check = new Scanner(System.in);
	private static Scanner Action6check = new Scanner(System.in);
	private static Scanner Action7check = new Scanner(System.in);
	private static Scanner Action8check = new Scanner(System.in);
	private static Scanner Action9check = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		final int ДpyгDEF = 5;
		final int KNIFEHEAD = 75;
		final int KNIFEHEARTCRIT = 25;
		final int KNIFEHEARTNONCRIT = 10;
		final int KNIFEGUT = 15;
		final int BLASTERHEAD = 250;
		final int BLASTERHEARTCRIT = 85;
		final int BLASTERHEARTNONCRIT = 35;
		final int BLASTERGUT = 50;
		double Attackmult = 1;
		int time = 0;
		int battery = 100;
		int health = 100;
		int defense = 0;
		int ehealth, x;
		byte turnindex = 0;
		double mobility = 1;
		//combat booleans
		boolean edeath = false, death = false, jump = false, duck = false, left = false, right = false;
		//equipment booleans
		boolean flare, rope, flashlight, bandage, knife = true;
		//logic booleans
		boolean inputcheck = false, c1 = false, c2 = false, c3 = false, c4 = false, c5 = false, c6 = false, c7 = false;
		
		System.out.println("As you slowly come to your senses, you notice that you are in a small room of a cave system.");
		System.out.println("You see a flare, some rope, a flashlight, a bandage, and a survival knife by your side.");
		System.out.println("The room is a dead end. It is slowly filling up with water! What will you do?");
		System.out.println("Will you *wait* to collect your posessions or *leave* immediately?");
		
		String input1 = Direction1check.nextLine();
		if(input1.equalsIgnoreCase("Wait"))
		{
			c1 = true;
			inputcheck = true;
		}
		
		if(input1.equalsIgnoreCase("Leave"))
		{
			c2 = true;	
			inputcheck = true;
		}
		
		if(inputcheck == false)
		{
			System.out.println("Only enter the commands marked with asterisks. Please restart the game.");
			System.exit(0);
		}
		
		if(c1 == true)
		{
			flare = true;
			rope= true;
			inputcheck = true;
			time++;
			
			System.out.println("You now have all of your posessions. You are forced to climb out of the room to escape the water.");
		}
		
		if(c2 == true)
		{
			flare = false;
			rope = false;
			inputcheck = true;
			
			System.out.println("You hastily climb out of the room to escape the water. You leave the flare and the rope, collecting the knife, flashlight, and bandage.");
		}
		
		c1 = false;
		c2 = false;
		inputcheck = false;
		
		System.out.println("The cave branches into two. To your left, an exit and daylight. To your right, an extension of the cave. You notice a plaque in front of you. It reads:");
		System.out.println("THE SECRETS OF THIS CAVE ARE VAST. THOSE WHO TURN BACK SHALL CONTINUE ON, WHEREAS THOSE WHO VENTURE IN SHALL EITHER ATTAIN VAST WEALTH AND GLORY OR DIE TRYING.");
		System.out.println("What do you do? Do you *leave* safely, or do you venture deeper and *go* into the cave to unveil its secrets?");

		String input2 = Direction2check.nextLine();
		
		if(input2.equalsIgnoreCase("Go"))
			inputcheck = true;
		
		if(input2.equalsIgnoreCase("Leave"))
		{
			c1 = true;
			inputcheck = true;
		}
		
		if(c1 == true)
		{
			System.out.println("You left the cave. The next day, out of curiousity, you return to its site. It has vanished completely.");
			System.out.println("You live the rest of your days regretting leaving the cave. If only...");
			System.exit(0);
		}
		
		if(inputcheck == false)
		{
			System.out.println("Only enter the commands marked with asterisks. Please restart the game.");
			System.exit(0);
		}
	
		c1 = false;
		inputcheck = false;
		
		System.out.println("As you begin walking deeper into the cave, the light level lowers. You can either use your flashlight to illuminate your path or continue walking in the dark, running your hand across the wall.");
		System.out.println("What do you do? Do you turn *on* your flashlight and use some of its battery, or keep it *off* and be forced to spend more time walking?");

		String input3 = Direction1check.nextLine();
		if(input3.equalsIgnoreCase("On"))
		{
			c1 = true;
			inputcheck = true;
		}
		
		if(input3.equalsIgnoreCase("Off"))
		{
			c2 = true;
			inputcheck = true;
		}
			
		if(inputcheck == false)
		{
			System.out.println("Only enter the commands marked with asterisks. Please restart the game.");
			System.exit(0);
		}

		if(c1 == true)
		{
			time = time + 2;
			battery = battery - 8;
			inputcheck = true;
			
			System.out.println("With your flashlight on, walking through the cave is a breeze. You make it through in less than half the time it would have taken if you kept your flashlight off. However, you used 8% of your flashlight battery.");
			System.out.println("Flashlight battery is now at "+battery+"%.");
		}
		
		if(c2 == true)
		{
			time = time+5;
			inputcheck = true;
		
			System.out.println("You keep your flashlight off. You almost trip, but you manage to get to the end of the tunnel without any injury. In addition, you saved 8% of the flashlight battery.");
			System.out.println("Flashlight battery is now at "+battery+"%.");
		}
		
		c1 = false;
		c2 = false;
		inputcheck = false;
		
		System.out.println("Press Enter to continue.");
		Continue1check.nextLine();
		
		System.out.println("You begin to be able to make out a fighting dummy in front of you. You eventually enter a well lit room. The dummy begins talking. You question your sanity.");
		System.out.println("Dummy: Traveller, I will introduce you to the fighting system. Take out your knife.");
		System.out.println("Do you *ignore* the dummy or *follow* its instructions?");
		
		String input4 = Direction1check.nextLine();
		if(input4.equalsIgnoreCase("Ignore"))
		{
			c1 = true;
			inputcheck = true;
		}
		
		if(input4.equalsIgnoreCase("Follow"))
		{
			c2 = true;
			inputcheck = true;
		}
		
		if(inputcheck = false)
		{
			System.out.println("Only enter the commands marked with asterisks. Please restart the game.");
			System.exit(0);
		}
		
		if(c1 == true)
			System.out.println("The sheer willpower of the dummy forced you to take your knife out.");
		if(c2 == true)
			System.out.println("You listen to the dummy, fearing its wrath.");
		
		c1 = false;
		c2 = false;
		inputcheck = false;
		x = (int)(Math.random()*100+1);
		
		int dhealth = 999999999;
		System.out.println("Dummy: Good. Now, I have 3 vulnurable regions: HEAD, HEART, and GUT. Each is more vulnurable than the next, however, the more vulnurable, the harder it is to hit.");
		System.out.println("Dummy: Go ahead and try attacking my head.");
		System.out.println("Press Enter to continue.");
		
		Continue2check.nextLine();
		System.out.println();
		System.out.println("You attacked the dummy's head.");
		System.out.println();
		
		if(x < 26)
		{
			dhealth = dhealth - 75;
			System.out.println("You struck its head perfectly! The dummy looks impressed.");
			System.out.println("You dealt 75 damage. The dummy now has "+dhealth+" health.");
			System.out.println("Dummy: Wow! I didn't expect you to hit me so hard the first time!");
		}
		if(x>26)
		{
			dhealth = dhealth - 0;
			System.out.println("You completley missed the dummy's head. The dummy looked dissapointed.");
			System.out.println("You dealt 0 damage. The dummy now has "+dhealth+" health.");
			System.out.println("Dummy: That's O.K. Remember, the more vulnurable, the harder to hit.");
		}
		
		x = (int)(Math.random()*100+1);
		System.out.println("Dummy: Alright, let's see if you can get a better hit on my heart. The difference here is that you are guaranteed damage, with a chance for a critical hit.");
		System.out.println();
		System.out.println("Press Enter to continue.");
		
		Continue3check.nextLine();
		System.out.println();
		System.out.println("You attacked the Dummy's heart.");
		System.out.println();
		
		if(x<50)
		{
			dhealth = dhealth - 25;
			System.out.println("You struck your dagger right through the dummy's heart. It is made of carpet.");
			System.out.println("You dealt 25 damage. The dummy now has "+dhealth+" health.");
			System.out.println("Dummy: Great hit!");
		}
		if(x>51)
		{
			dhealth = dhealth - 10;
			System.out.println("You missed the dummy's heart. You still buried your knife deep in its chest.");
			System.out.println("You dealt 10 damage. The dummy now has "+dhealth+" health.");
			System.out.println("Dummy: As you can see, even though you didn't get a critical hit, you still dealt some damage.");
		}
		System.out.println("Dummy: Finally, try attacking my gut. You don't have a critical strike chance, however, you have guaranteed damage.");
		
		System.out.println("Press Enter to continue.");
		Action2check.nextLine();
		
		System.out.println("You attacked the Dummy's gut.");
		System.out.println();
		
		dhealth = dhealth - 15;
		System.out.println("You dug your knife right into the dummy's gut. It began to shake violently. You quickly retract your weapon.");
		System.out.println("You dealt 15 damage. The dummy now has "+dhealth+" health.");
		System.out.println("Dummy: As you can see, no matter what you do, you would deal 15 damage to me.");
		System.out.println();
		System.out.println("Dummy: It was nice seeing you. And maybe I'll see you around later.");
		System.out.println("The dummy began to fade into nothingness. You left the room with a feeling of knowledge.");
		time++;
		System.out.println("Press Enter to continue.");
		Continue5check.nextLine();
		
		System.out.println("As you stepped out of the room, you saw a strange rock on the ground. You poked it. It moved.");
		System.out.println("As you studied it more closely, you realised that it was actually a giant cell. It was about a half meter across and it started to move towards you.");
		System.out.println("You stuck your arm into the slime. It tingled.");
		System.out.println("Your ATTACK lowered!!!");
		Attackmult = .75;
		System.out.println("You engaged the slime!");
		
		System.out.println("The dummy began infecting your thoughts.");
		System.out.println("Dummy: This is a slime. Let it hit you, so you can learn how your opponents will fight back.");
		
		System.out.println("Press Enter to continue.");
		Continue6check.nextLine();
		
		x = (int)(Math.random()*70+1);
		
		if(x < 0)
		{
			System.out.println("The slime lunged for your head!! What will you do?");
			System.out.println("Dummy: You have 4 options here: You can dodge *left*, dodge *right*, *duck*, or *jump*. Try evading the slime!");
			
			String input7 = Action3check.nextLine();
			
			if(input7.equalsIgnoreCase("Left"))
				left = true;
			if(input7.equalsIgnoreCase("Right"))
				right = true;
			if(input7.equalsIgnoreCase("Jump"))
				jump = true;
			if(input7.equalsIgnoreCase("Duck"))
				duck = true;
			
			if(left == true||right == true||duck == true)
			{
				System.out.println("You got out of the slime's way just in time. It whizzed by your head.");
				System.out.println("Dummy: Great job! Now attack it!");
				inputcheck = true;
			}
			
			if(jump == true)
			{
				health = health - 5;
					
				System.out.println("You jumped. The slime slammed right into your gut. It dealt 5 damage!");
				System.out.println("Dummy: A key factor of surviving is figuring out which way you need to dodge. Now attack the slime!");
				inputcheck = true;
					
			}
			if(inputcheck = false)
			{
				System.out.println("Only enter the commands marked with asterisks. Please restart the game.");
				System.exit(0);
			}
		}
		
		else if (x < 70)
		{
			System.out.println("The slime lunged for your gut!! What will you do?");
			System.out.println("Dummy: You have 4 options here: You can dodge *left*, dodge *right*, *duck*, or *jump*. Try evading the slime!");
		
			String input7 = Action3check.nextLine();
		
			if(input7.equalsIgnoreCase("Left"))
				left = true;
			if(input7.equalsIgnoreCase("Right"))
				right = true;
			if(input7.equalsIgnoreCase("Jump"))
				jump = true;
			if(input7.equalsIgnoreCase("Duck"))
				duck = true;
			
			if(left == true||right == true||duck == true)
			{
				System.out.println("You got out of the slime's way just in time. It whizzed by your head.");
				System.out.println("Dummy: Great job! Now attack it!");
				inputcheck = true;
			}
			
			if(jump == true)
			{
				health = health - 5;
				
				System.out.println("You jumped. You spread your legs to let it go right through. The slime passed in between your legs.");
				System.out.println("Dummy: Great job! Now attack it!");
				inputcheck = true;
				
			}
			if(inputcheck = false)
			{
				System.out.println("Only enter the commands marked with asterisks. Please restart the game.");
			System.exit(0);
			}
		}
		
		else
		{

			System.out.println("The slime lunged for your heart!! What will you do?");
			System.out.println("Dummy: You have 4 options here: You can dodge *left*, dodge *right*, *duck*, or *jump*. Try evading the slime!");
			
			String input7 = Action3check.nextLine();
			
			if(input7.equalsIgnoreCase("Left"))
				left = true;
			if(input7.equalsIgnoreCase("Right"))
				right = true;
			if(input7.equalsIgnoreCase("Jump"))
				jump = true;
			if(input7.equalsIgnoreCase("Duck"))
				duck = true;
			
			if(left == true||right == true||duck == true)
			{
				inputcheck = true;
				
				System.out.println("You got out of the slime's way just in time. It whizzed right by you.");
				System.out.println("Dummy: Great job! Now attack it!");
			}
			
			if(jump == true)
			{
				health = health - 5;
				inputcheck = true;
					
				System.out.println("You jumped. The slime got a  hit to your gut. It dealt 5 damage!");
				System.out.println("Dummy: A key factor of surviving is figuring out which way you need to dodge. Now attack the slime!");
					
			}
			if(inputcheck == false)
			{
					System.out.println("Only enter the commands marked with asterisks. Please restart the game.");
					System.exit(0);
			}
		}
		
		left = false;
		right = false;
		jump = false;
		duck = false;
		
		inputcheck = false;
		
		System.out.println();
		System.out.println("NOTE: YOUR ATTACK MULTIPLIER IS AT 3/4.");
		System.out.println("Dummy: As you may notice, you have a lower attack multiplier. This is because the slime 'attacking' your arm decreased your attack strength. If it had attacked your legs, it would have hurt your chances of a successful dodge.");
		System.out.println("Dummy: You have a scanner for your enemy's stats. It automatically activates and gives you info on your opponnent after your first turn. Here it goes!");
		System.out.println("Press Enter to continue.");

		Continue6check.nextLine();
		System.out.println("SLIME: 0 DEF 1 HP 5 ATK. A LARGE, DELICATE UNICELLULAR ORGANISM. ITS MEANS OF SURVIVAL ARE UNKNOWN.");
		System.out.println();
		System.out.println("Dummy: The DEF stat is your opponnent's defense. It shows you how much damage it can absorb without taking more than 1. For example, if an opponnent had 5 defense and you attacked with 3, you would deal the default 1 damage.");
		System.out.println("Dummy: However, if you attacked with 10 instead of 3, you would have dealt 5 damage. This means an attack of 5 and 6 would both deal 1. If you use armor, you can increase your own defense.");
		System.out.println();
		System.out.println("Dummy: Next is HP. This stat shows how much damage your opponnent can take. If you get their HP to 0, they die.");
		System.out.println();
		System.out.println("Dummy: Finally is ATK. This shows the default gut damage your opponnent deals. However, due to different damage rates, your opponnent deals 2/3 ATK on non-critical heart, 2 ATK on critical heart, and 5 ATK on a head strike.");
		System.out.println("Dummy: So dodging headstrikes is very important!");
		System.out.println();
		System.out.println("Dummy: You have 100 health. If your health ever reaches 0, you die. So don't let that happen!");
		System.out.println("Dummy: You can attack this slime anywhere and kill it. But you'll need to use your knife. If you, for example, punched it, you would have a chance of puncturing it, but also a chance of doing nothing.");
		System.out.println("Dummy: It's important to know what attacks will be effective against different enemies.");
		System.out.println();
				
		System.out.println("Enter any character to attack.");
		Continue4check.nextLine();
		
		System.out.println("You stabbed your knife right into the slime. It fell apart and absorbed into the ground. You began to feel nauseous.");
		
		if(health < 100)
		{
			System.out.println("Dummy: You took damage in that battle. I'll heal you.");
			System.out.println("You were healed to FULL health!");
			System.out.println();
		}
		
		System.out.print("Dummy: You ");
		if(health < 100)
			System.out.print("also ");
		System.out.println("got a DEBUFF. This hurt your overall fighting strength.");
		health = 100;
		System.out.println("Dummy: I'll remove that.");
		Attackmult = 1;
		System.out.println("Your ATTACK increased! Your attack multiplier is now x1.");
		System.out.println();
		System.out.println("Dummy: Alright. I won't be holding your hand anymore. So... bye!");
		System.out.println("The presence of the dummy faded from your mind. Finally, you had full controll over yourself again.");
		System.out.println("You continue your journey and travel further into the cave.");
		System.out.println();
		
		System.out.println("Press Enter to continue.");
		Continue5check.nextLine();
		
		//TextCave by Blueshoes317
		time++;
		
		System.out.println("As you walk away, the cave in front of you turns into a ravine which you are at the bottom of. The various skylights make for a strange environment.");
		System.out.println("You spot an unlit portion of the wall. You peer in and see a faint glow a decent distance away.");
		System.out.println("What do you do? Do you *inspect* the light or do you *ignore* it?");
		String input16 = Direction3check.nextLine();
		
		if(input16.equalsIgnoreCase("Inspect"))
		{
			inputcheck = true;
			c1 = true;
		}
		
		if(input16.equalsIgnoreCase("Ignore"))
		{
			inputcheck = true;
			c2 = true;
		}
			
		if(inputcheck = false)
		{
			System.out.println("Only enter the commands marked with asterisks. Please restart the game.");
			System.exit(0);
		}
		
		if(c1 == true)
			System.out.println("You chose to inspect the light.");
		if(c2 == true)
			System.out.println("Despite your choice to ignore it, the light inspired your curiosity. Before you think it over again, you decide to check the light anyways.");
		
		System.out.println("As you walked into the small room, you begin to see a faint glow of a fire.");
		System.out.println("Suddenly, a large creature jumped from the shadows.");
		System.out.println("You engaged the Дpyг!");
		System.out.println("Press Enter to continue.");
		Continue7check.nextLine();
		
		ehealth = 75;
		
		System.out.println("Дpyг: RRRRGHHHH...");
		System.out.println("The Дpyг seemed distressed, possibly in pain.");
		System.out.println("It resembled a creature from a video game you played a few years ago, Fallout. You can't recall what its name was. ...Deathclaw, maybe?");
		System.out.println();
		System.out.println("Since you were engaged by the Дpyг, it is your turn first.");
	
		boolean fight = true;
		health = 100;
		
		while (fight = true)
		{
			
			System.out.println("Will you strike for the *head*, *heart*, or *gut*?");
			String input19 = Action1check.nextLine();
			
			if(input19.equalsIgnoreCase("Gut"))
			{
				
				ehealth = (int)(ehealth-((KNIFEGUT*Attackmult)-ДpyгDEF));
				System.out.println("You lunged for the Дpyг's gut. You dealt "+(int)((KNIFEGUT*Attackmult)-ДpyгDEF)+" damage! The Дpyг has "+ehealth+" health remaining.");
				System.out.println("Дpyг: RRRNNGH...");
					
			}
			else 
			{
				x = (int)(Math.random()*100+1);
				if(input19.equalsIgnoreCase("Heart"))
				{
					if(x<51)
					{
						ehealth = (int)(ehealth-((KNIFEHEARTCRIT*Attackmult)-ДpyгDEF));
						System.out.println("You lunged for the Дpyг's heart. You dealt "+(int)((KNIFEHEARTCRIT*Attackmult)-ДpyгDEF)+" damage with a critical hit! The Дpyг has "+ehealth+" health remaining.");
					}
					else
					{
						ehealth = (int)(ehealth-((KNIFEHEARTNONCRIT*Attackmult)-ДpyгDEF));
						System.out.println("You lunged for the Дpyг's heart. You dealt "+(int)((KNIFEHEARTNONCRIT*Attackmult)-ДpyгDEF)+" damage with a non-critical hit! The Дpyг has "+ehealth+" health remaining.");
					}
				}
				else
				{
					if(input19.equalsIgnoreCase("Head"))
					{
						if(x<26)
						{
							ehealth = (int)(ehealth-((KNIFEHEAD*Attackmult)-ДpyгDEF));
							System.out.println("You lunged for the Дpyг's head. You dealt "+(int)((KNIFEHEAD*Attackmult)-ДpyгDEF)+" damage with a hit! The Дpyг has "+ehealth+" health remaining.");
						}
						else
						{
							System.out.println("You lunged for the Дpyг's head. You missed! The Дpyг has "+ehealth+" health remaining.");
						}
					}
					else 
					{
						System.out.println("Only enter the commands marked with asterisks. Please restart the game.");
						System.exit(0);
					}
				}
			}
			
			if (ehealth <= 0)
				break;
			
			if(turnindex == 0)
				System.out.println("Дpyг: 5 DEF 75 HP 10 ATK. A LARGE, TALL CREATURE. IT HUNTS USING ITS MASSIVE CLAWS, CAPABLE OF SLASHING THROUGH NEARLY ANYTHING.");
			
			if(ehealth>0)
			{
				
				x = (int)(Math.random()*100+1);
			if(x<11)
			{
				System.out.println("The Дpyг swiped low at your legs. How will you evade the attack?");
				System.out.println("Will you dodge *left*, dodge *right*, *jump*, or *duck*?");
				String input21 = Action4check.nextLine();
				
				if(input21.equalsIgnoreCase("Left"))
					left = true;
				if(input21.equalsIgnoreCase("Right"))
					right = true;
				if(input21.equalsIgnoreCase("Jump"))
					jump = true;
				if(input21.equalsIgnoreCase("Duck"))
					duck = true;
			
				if(left == true||right == true || duck == true)
				{
					mobility = .65;
					inputcheck = true;
					System.out.println("Your decision led to the Дpyг getting a successful hit on your legs. Your MOBILITY lowered!");
				}
					if(jump == true)
				{
					inputcheck = true;
					x = (int)(Math.random()*100+1);
					if((x*mobility)<70)
					{
						System.out.println("You jumped right out of the way of the Дpyг's strike. You evaded the hit!");
					}
					else
					{
						mobility = .65;
						System.out.println("Despite your efforts, the Дpyг was still able to get a hit on your legs. Your MOBILITY lowered!");
					}
				}

				if(inputcheck == false)
				{
					System.out.println("Only enter the commands marked with asterisks. Please restart the game.");
					System.exit(0);
				}
			}
			else if(x<16)
			{
				System.out.println("The Дpyг swiped overhand at your arms. How will you evade the attack?");
				System.out.println("Will you dodge *left*, dodge *right*, *jump*, or *duck*?");
				String input21 = Action4check.nextLine();
				
				if(input21.equalsIgnoreCase("Left"))
					left = true;
				if(input21.equalsIgnoreCase("Right"))
					right = true;
				if(input21.equalsIgnoreCase("Jump"))
					jump = true;
				if(input21.equalsIgnoreCase("Duck"))
					duck = true;
				
				if(right == true || left == true)
				{
					inputcheck = true;
					System.out.println("You were able to get out of the way just in time. You evaded the hit!");
				}

				if(duck == true||jump == true)
				{
					inputcheck = true;
					Attackmult = .8;
					System.out.println("The Дpyг still got a hit on you because it swiped overhand. Your ATTACK lowered!");
				}
				if(inputcheck == false)
				{
					System.out.println("Only enter the commands marked with asterisks. Please restart the game.");
					System.exit(0);
				}
			}
			else if (x<35)
			{
				System.out.println("The Дpyг swiped sideways at your head! How will you evade the attack?");
				System.out.println("Will you dodge *left*, dodge *right*, *jump*, or *duck*?");
				String input21 = Action4check.nextLine();
				
				if(input21.equalsIgnoreCase("Left"))
					left = true;
				if(input21.equalsIgnoreCase("Right"))
					right = true;
				if(input21.equalsIgnoreCase("Jump"))
					jump = true;
				if(input21.equalsIgnoreCase("Duck"))
					duck = true;
			
				if(left == true||right == true)
					health = health-50;
				if(left == true||right == true)
				{
					inputcheck = true;
					System.out.println("Your decision led to your head getting swiped by the Дpyг. You took 50 damage!");
				}
				if(input21.equalsIgnoreCase("Jump"))
					health = health-10;
				if(input21.equalsIgnoreCase("Jump"))
				{
					inputcheck = true;
					System.out.println("Your decision led to your gut getting swiped by the Дpyг. You took 10 damage!");
				}
				if(input21.equalsIgnoreCase("Duck"))
				{
					inputcheck = true;
					System.out.println("You ducked out of the way. The Дpyг's strike went right over your head. You evaded the hit!");
				}
				if(inputcheck == false)
				{
					System.out.println("Only enter the commands marked with asterisks. Please restart the game.");
					System.exit(0);
				}
			}
			else if(x<70)
			{
				System.out.println("The Дpyг swiped overhand at your heart. How will you evade the attack?");
				System.out.println("Will you dodge *left*, dodge *right*, *jump*, or *duck*?");
				String input21 = Action4check.nextLine();
				
				if(input21.equalsIgnoreCase("Left"))
					left = true;
				if(input21.equalsIgnoreCase("Right"))
					right = true;
				if(input21.equalsIgnoreCase("Jump"))
					jump = true;
				if(input21.equalsIgnoreCase("Duck"))
					duck = true;
				
				if(left == true || right == true)
				{
					inputcheck = true;
					System.out.println("You spun to the side and the Дpyг missed. You evaded the hit!");
				}
				if(jump == true)
					health = health-10;
				if(jump == true)
				{
					inputcheck = true;
					health = health-10;
					System.out.println("Your decision led to your gut getting swiped by the Дpyг. You took 10 damage!");
				}
				if(duck == true)
				{
					inputcheck = true;
					System.out.println("You ducked out of the way. The Дpyг's strike hit your head. You took 50 damage!");
				}
				if(inputcheck == false)
				{
					System.out.println("Only enter the commands marked with asterisks. Please restart the game.");
					System.exit(0);
				}	
			}
			else
			{
				System.out.println("The Дpyг swiped sideways at your gut. How will you evade the attack?");
				System.out.println("Will you dodge *left*, dodge *right*, *jump*, or *duck*?");
				String input21 = Action4check.nextLine();
				
				if(input21.equalsIgnoreCase("Left"))
					left = true;
				if(input21.equalsIgnoreCase("Right"))
					right = true;
				if(input21.equalsIgnoreCase("Jump"))
					jump = true;
				if(input21.equalsIgnoreCase("Duck"))
					duck = true;
				
				if(left == true||right == true)
					health = health-10;
				if(left == true||right == true)
				{
					inputcheck = true;
					System.out.println("You spun to the side and the Дpyг's hand connected anyways. You took 10 damage!");
				}
				if(jump == true)
				{
					inputcheck = true;
					mobility = .65;
					System.out.println("You jumped and got your legs caught. Your MOBILITY decreased!");
				}
				if(duck == true)
				{
					inputcheck = true;
					System.out.println("You ducked out of the way. The Дpyг's strike went right over your head. You evaded the hit!");
				}
				if(inputcheck == false)
				{
					System.out.println("Only enter the commands marked with asterisks. Please restart the game.");
					System.exit(0);
				}
			}
		
			
			inputcheck = false;
			left = false;
			right = false;
			jump = false;
			duck = false;
			
			if (health == 0||health < 0)
			{
				System.out.println();
				System.out.println("Despite your best efforts, you were killed on your journey.");
				System.out.println("As your life flashed by your eyes, you realised what your mistake was. If only there was a way to try again!");
				System.exit(0);
			}
			
			turnindex++; 
			
			}
		}
		
		fight = false;
		Attackmult = 1;
		mobility = 1;
		health = 100;
		
		System.out.println();
		System.out.println("Taking "+turnindex+" turns, you finally killed the Дpyг. You felt a surge of power. Your Atack multiplier and mobility were all set to default! Your HEALTH was set to 100!");
		System.out.println("You noticed that the light was still there. You checked it. It was a chest!");
		System.out.println("You quickly opened it and saw a set of leather armor inside!");
		System.out.println("You equiped the leather armor. Your defense rose to 5!");
		defense = 5;
		
		System.out.println("Press Enter to continue.");
		Continue8check.nextLine();
		
		System.out.println("You approached another room. You enter it and see 7 doors, each with an image printed on:");
		System.out.println("One with a sword, one with a snowflake, one with a flame, one with a rock, one with a lightning bolt, one with a picture of the sun, and the last with a speaker.");
		System.out.println("Will you go to the door with the *sword*, *snow*, *fire*, *rock*, *bolt*, *sun*, or *sound*?");
		String input23 = Direction4check.nextLine();
		
		if(input23.equalsIgnoreCase("Sword"))
		{
			System.out.println("You opened the door. You cut your finger on the sharp edge. You proceeded into the room.");
		}
		if(input23.equalsIgnoreCase("Snow"))
		{
			System.out.println("You opened the door. The handle was cool to the touch. You proceeded into the room.");
		}
		if(input23.equalsIgnoreCase("Fire"))
		{
			System.out.println("You opened the door. The handle was warm to the touch. You proceeded into the room.");
		}
		if(input23.equalsIgnoreCase("Rock"))
		{
			System.out.println("You opened the door. The handle fell off, hitting your toe. You proceeded into the room.");
		}
		if(input23.equalsIgnoreCase("Sun"))
		{
			System.out.println("You opened the door. The room behind it was slightly bright. You proceeded into the room.");
		}
		if(input23.equalsIgnoreCase("Bolt"))
		{
			System.out.println("You opened the door. You got a small static shock. You proceeded into the room.");
		}
		if(input23.equalsIgnoreCase("Sound"))
		{
			System.out.println("You opened the door. The door creaking open was nearly uncomfortably loud. You proceeded into the room.");
		}
		
		System.out.println();
		System.out.println("The room had a single pedestal. Upon it layed a device similar to a particle blaster. You immediatley recognized it as a small hybrid blaster from the video game EVE Online. The plaque read:");
		System.out.println("LIGHT ION BLASTER: COLLECTS AIR MOLECULES AND POLARIZES ATOMS. IONIZES AND BLASTS IONS AND ELECTRONS SEPERATELY TO TARGET, EXPLODING AND REJOINING TO CREATE AIR ON IMPACT.");
		System.out.println("Despite the technical challenges of creating such a device, this blaster seems to be contained in the size of a pistol. The barrel is elongated, probably to provide surface to collect air.");
		System.out.println("You have never seen one so small and light. It would likely be illegal on the surface.");
        System.out.println("You eqqipped the PROTON BLASTER! Base gut damage: 50");
        System.out.println("Press Enter to continue.");
		Continue9check.nextLine();
        
        System.out.println("As you continue on your journey, you come across a dead end. However, you notice that one of the walls is peckeled with holes. You look in, and see it is only a centimenter wide!");
        System.out.println("How will you continue? Will you *shoot* the wall with your blaster or *throw* another rock at it?");
		String input25 = Action5check.nextLine();
        
        if(input25.equalsIgnoreCase("Shoot"))
        {
            time++;
            System.out.println("You used your blaster repeatedly to shoot holes into the wall. The blaster had no battery display, probably using RTG energy to power itself.");
        }
        if(input25.equalsIgnoreCase("Throw"))
        {
            time = time + 2;
            System.out.println("You found rocks to throw at the wall. It took a while, however, you eventually did manage to punch a hole big enough for you to squeeze through to get to the other side.");
        }
        
        System.out.println("In the next room, you found another chest. As you went to open it, you saw a large bat come nearer to you. You drew your blaster!");
        System.out.println("You engaged the GIANT BAT!");
        System.out.println("Press Enter to continue.");
		Continue10check.nextLine();
        
		System.out.println("Since you engaged the Giant Bat, it is its turn first.");
		ehealth = 250;
		
		turnindex = 0;
		inputcheck = false;
		fight = true;
		
		while(fight == true)
		{
			
			System.out.println();
			if(turnindex == 0)
				System.out.println("The Giant Bat took flight!");
			System.out.println("The Giant bat attempted to scratch your face!");
			System.out.println("You attempted to duck.");
			
			x = (int)(Math.random()*100+1);
			
			if(x>40)
			{
				health = health - 15;
				System.out.println("Your attempt to duck failed. Unfortunatley, the bat was too fast and still got at your face. You lost 15 health! You have "+health+" health remaining.");
			}
			else
				System.out.println("You were able to duck from the bat without taking any damage!");
			if(turnindex == 0)
			{
				System.out.println("The dummy began infecting your thoughts once again.");
				System.out.println("Dummy: The bat has 3 vulnurable regions: Head, Torso, and Wing. However, its wings will be invulnurable until it eventually begins to tire out.");
			}
			
			System.out.println("How will you attack? *Head*, *Torso*, or *Wing*?");
			String input27 = Action6check.nextLine();
			
			if(input27.equalsIgnoreCase("Head"))
			{
				
				inputcheck = true;
				x = (int)(Math.random()*100+1);
				if(x>35)
				{
					System.out.println("The bat was too fast. You missed the shot!");
				}
				else
				{
					ehealth = ehealth-35;
					System.out.println("You hit the bat and got 35 damage in with a glancing hit! The bat has "+ehealth+" health remaining.");
				}
				
			}
			//TextCave by Blueshoes317
			
			if(input27.equalsIgnoreCase("Torso"))
			{
				inputcheck = true;
				x = (int)(Math.random()*100+1);
				if(x>65)
				{
					System.out.println("The bat was too fast. You missed the shot!");
				}
				else
				{
					ehealth = ehealth-15;
					System.out.println("You hit the bat and got 15 damage in with a glancing hit! The bat has "+ehealth+" health remaining.");
				}
			}
			
			if(input27.equalsIgnoreCase("Wing"))
			{
				inputcheck = true;
				System.out.println("The wings aren't vulnurable yet! The bat hid them behind its body and continuted flying.");
			}
			
			if(inputcheck == false)
			{
						System.out.println("Only enter the commands marked with asterisks. Please restart the game.");
						System.exit(0);
			}
			
			if(turnindex == 0)
			{
				System.out.println("GIANT BAT: 5 DEF 250 HP 15 ATK. A LARGE BAT THAT LIVES IN CAVERNS. IT FLYS AROUND, OUT OF REACH OF ITS PREY, SCRATCHING IT, UNTIL IT EVENTUALLY DIES TO BLOOD LOSS. DUE TO ITS SPEED, HITS ARE HARD TO GET ON IT.");
			}
			
			inputcheck = false;
			turnindex++;
			
			if(turnindex == 3)
			{
				break;
			}
		
		}
		
		while(turnindex>=2)
		{
			if(turnindex == 3)
			{
				System.out.println();
				System.out.println("The bat's wings became vulnurable! They may be a weak spot...");
			}
			
			System.out.println("The Giant bat attempted to scratch your face!");
			System.out.println("You attempted to duck.");
			
			x = (int)(Math.random()*100+1);
			
			if(x>40)
			{
				health = health - 15;
				System.out.println("Your attempt to duck failed. Unfortunatley, the bat was too fast and still got at your face. You lost 15 health! You have "+health+" health remaining.");
			}
			else
				System.out.println("You were able to duck from the bat without taking any damage!");
			
            if(health <= 0)
            {
                System.out.println("Despite your imminent death, you mustered the strength for one last attack.");
            }
            
			System.out.println("How will you attack? *Head*, *Torso*, or *Wing*?");
			String input28 = Action7check.nextLine();
			
			if(input28.equalsIgnoreCase("Head"))
			{
				inputcheck = true;
				x = (int)(Math.random()*100+1);
				if(x>35)
				{
					System.out.println("The bat was too fast. You missed the shot!");
				}
				else
				{
					ehealth = ehealth-35;
					System.out.println("You hit the bat and got 35 damage in with a glancing hit! The bat has "+ehealth+" health remaining.");
				}
				
			}
			
			if(input28.equalsIgnoreCase("Torso"))
			{
				inputcheck = true;
				x = (int)(Math.random()*100+1);
				if(x>65)
				{
					System.out.println("The bat was too fast. You missed the shot!");
				}
				else
				{
					ehealth = ehealth-15;
					System.out.println("You hit the bat and got 15 damage in with a glancing hit! The bat has "+ehealth+" health remaining.");
				}
			}
			
			if(input28.equalsIgnoreCase("Wing"))
			{
				inputcheck = true;
				x = (int)(Math.random()*100+1);
				if(x>35)
				{
					System.out.println("You weren't able to hit the wings! The bat escaped unscathed!");
				}
				else
				{
					System.out.println("You hit the bat's wings! As it fell to the ground, you began shooting it rapidly with your blaster. Before it reached you, it was dead!");
					System.out.println();
					edeath = true;
				}
			}
			
			if(inputcheck == false)
			{
						System.out.println("Only enter the commands marked with asterisks. Please restart the game.");
						System.exit(0);
			}
			
			inputcheck = false;
			
			if(edeath == true)
			{
				break;
			}
				
			if (health <= 0)
				death = true;
			else
				death = false;
			
			if (ehealth <= 0)
				edeath = true;
			else
				edeath = false;
			
			if(death == true)
			{
				System.out.println();
				System.out.println("Despite your best efforts, you were killed on your journey.");
				System.out.println("As your life flashed by your eyes, you realised what your mistake was. If only there was a way to try again!");
				System.exit(0);
			}
			if(edeath == true)
			{
				System.out.println("Through a long fight, you finally killed the Giant Bat");
				System.out.println();
				break;
			}
            turnindex++;
		}
		
		System.out.println("You approached the chest. It contained an iron helmet. Although heavy, you decided it was best to keep it on. Your DEFENSE rose to 10!");
		System.out.println("Inspecting the corpse of the bat, you took some scientfic notes. The anatomy was fascinating.");
		System.out.println("You saw a plus symbol on the ground. You stepped on it. Your health was fully restored!");
		health = 100;
        System.out.println("Press Enter to continue.");
		Continue13check.nextLine();
		
		System.out.println();
		System.out.println();
		System.out.println("You walked into a large, empty room.");
		System.out.println("You began to feel an onimous presence.");
		System.out.println("Suddenly, you saw one of the walls move.");
		System.out.println("It wasn't a wall.");
		System.out.println("It was a slime.");
		System.out.println("You engaged KING SLIME!!!");
		System.out.println("Press Enter to continue.");
		Action9check.nextLine();
		turnindex = 0;
		ehealth = 1;
		
		
		turnindex++;
		System.out.println("As you approached the King Slime, you drew your blaster.");
		System.out.println("You shot the King Slime. It split itself into countless parts to dodge the attack. However, a small piece of it was hit!");
		System.out.println("The King slime got slightly smaller!");
		System.out.println("KING SLIME: 0 DEF 1 HP 50 ATK: A GIANT SLIME. IT CONSUMES FOOD BY COMPLETLEY SURROUNDING IT AND DISSOLVING IT.");
		System.out.println("Press Enter to attack.");
		Continue11check.nextLine();
		
		turnindex++;
		System.out.println("You shot one part of the King Slime. Although this smaller piece was destroyed, the rest rejoined into one!");
		System.out.println("The King slime got slightly smaller!");
		System.out.println("Press Enter to attack.");
		Continue14check.nextLine();
		
		turnindex++;
		turnindex++;
		
		fight = true;
		
		while(turnindex<7)
		{
			if(turnindex == 4)
				System.out.println("The King Slime split into 5 parts and began moving towards you! You realised that there were 4 parts, one for each of your limbs, and one for your main body!");
			else
				System.out.println("The slimes got closer!");
			System.out.println("You shot one of them! You predict they will reach you in "+(7-turnindex)+" turns!");
			System.out.println("Press Enter to continue.");
			Continue12check.nextLine();
			turnindex++;
			if(turnindex == 7)
			{
				break;
			}
		}
		
		left = false;
		right = false;
		jump = false;
		duck = false;
		
		System.out.println("As the slimes rejoined, the King Slime lunged for your head! How will you evade it?");
		System.out.println("Will you dodge *left*, dodge *right*, *jump*, or *duck*?");
		String input31 = Action8check.nextLine();
		
		if(input31.equalsIgnoreCase("Left"))
			left = true;
		if(input31.equalsIgnoreCase("Right"))
			right = true;
		if(input31.equalsIgnoreCase("Jump"))
			jump = true;
		if(input31.equalsIgnoreCase("Duck"))
			duck = true;
		
		if(left == true||right == true||duck == true||jump == true)
		{
			inputcheck = true;
			System.out.println("The King Slime corrected for your dodge and hit your torso. It completley surrounded your body!");
			System.out.println("As the slime began edging towards your head, you managed to free your arm. You grabbed your knife and dug it into the side of the King Slime just before you went unconcious!");
			System.out.println("");
			System.out.println("You slowly came to your senses. You saw the membrane of the King Slime. You defeated it!");
		}
		else
		{
				System.out.println("Only enter the commands marked with asterisks. Please restart the game.");
				System.exit(0);
		}
		
		System.out.println("You continued on your journey deeper into the cave.");
		System.out.println();
		
		System.out.println("You came upon another dead end. Turning on your flashlight, you see a pool of water near you, as well as a diving suit next to you.");
		System.out.println("You quickly realised what fate had in mind for you. You checked the flashlight. It was waterproof to 5 meters!");
		System.out.println("You put the diving suit on and jumped in.");
		System.out.println("Press Enter to continue.");
		Continue15check.nextLine();
		
		boolean fouro = false, sixfour = false, seventhree = false, ninenine = false, onetwosix = false; //booleans for switches
		boolean seveno = false, sevenone = false, onethreeo = false, passo = false, passtwo = false; //booleans for blocks and special messages
		boolean forwards = false, backwards = false; //additional directional checkers, jump/duck wouldn't work
		boolean airsevenone = true, airseveno = true;
		
		boolean mbatterythisturn = false; //since battery reduces by .5%/turn, this boolean flips every movement, reducing battery by 1 per 2 turns.
		short placement = 1; //each block was assigned a number which corresponds to where it is, as per http://tinyurl.com/yxkvvcqp
		byte breath = 12; //Shows how many blocks you can still survive for without air
		byte trace = 0; //Traces direction of travel for 'forwards' and 'to the right', etc. 
		/*
		 * 1: from below, going up
		 * 2: from above, going down
		 * 3: from right, going left
		 * 4: from left, going right
		 */
		
		while(placement != 132)
		{
			
			switch (placement)
			{
			
			case 1:
			
				breath--;
				if(mbatterythisturn == true)
				{
					mbatterythisturn = false;
					battery --;
					System.out.println("Your battery is now at "+battery+"%.");
				}
				else
					mbatterythisturn = true;
				if(trace == 0)
				{
					System.out.println("You turned on your flashlight, it being the only way to see. Your flashlight battery is now at "+battery+"%.");
					System.out.println("You see that the cavern is made up of squares. On the wall, you see text. It reads \"https://tinyurl.com/y2y6zr4n\". You have no understanding of it.");
					System.out.println("You have "+breath+" air left.");
					System.out.println("Your only option for movement is forwards.");
					System.out.println("Press Enter to go forwards.");
					left = true;
				}
				if(trace == 2)
				{
					System.out.println("Your only option for movement is backwards.");
					System.out.println("Press Enter to go backwards.");
					left = true;
				}
				trace = 1;
				String input5 = Direction5check.nextLine();
				
				if(input5.equalsIgnoreCase("131"))
					placement = 131;
					
				else
					placement = 2;
				
			break;
			
			case 2:
			
				breath --;
				if(mbatterythisturn == true)
				{
					mbatterythisturn = false;
					battery --;
					System.out.println("Your battery is now at "+battery+"%.");
				}
				else
					mbatterythisturn = true;
				System.out.println("You have "+breath+" air left.");
				if(trace == 1)
				{
					System.out.println("In all directions are normal squares, except for the square behind you, which was your starting position.");
					System.out.println("Will you go *right*, *left*, *forwards*, or *backwards*?");
					String input37 = Direction6check.nextLine();
					
					if(input37.equalsIgnoreCase("Left"))
						left = true;
					if(input37.equalsIgnoreCase("Right"))
						right = true;
					if(input37.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input37.equalsIgnoreCase("Backwards"))
						backwards = true;
					
					if(left == true)
					{
						System.out.println("You went to the normal square to your left.");
						placement = 4;
						trace = 3;
					}
					if(right == true)
					{
						System.out.println("You went to the normal square to your right.");
						placement = 3;
						trace = 4;
					}
					if(forwards == true)
					{
						System.out.println("You went to the normal square ahead of you.");
						placement = 28;
						trace = 1;
					}
					if(backwards == true)
					{
						placement = 1;
						System.out.println("You went to your starting square behind you.");
						trace = 2;
					}
					
				}
				else if(trace == 2)
				{
					System.out.println("In all directions are normal squares, except for the square in front of you, which was your starting position.");
					System.out.println("Will you go *right*, *left*, *forwards*, or *backwards*?");
					String input37 = Direction6check.nextLine();
					
					if(input37.equalsIgnoreCase("Left"))
						left = true;
					if(input37.equalsIgnoreCase("Right"))
						right = true;
					if(input37.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input37.equalsIgnoreCase("Backwards"))
						backwards = true;
					
					if(left == true)
					{
						System.out.println("You went to the normal square to your left.");
						placement = 3;
						trace = 4;
					}
					if(right == true)
					{
						System.out.println("You went to the normal square to your right.");
						placement = 4;
						trace = 3;
					}
					if(forwards == true)
					{
						System.out.println("You went to your starting square ahead of you.");
						placement = 1;
						trace = 2;
					}
					if(backwards == true)
					{
						placement = 28;
						System.out.println("You went to the normal square behind you.");
						trace = 1;
					}
				}
				else if(trace == 3)
				{
					System.out.println("In all directions are normal squares execpt for your left, which is your starting square.");
					System.out.println("Will you go *right*, *left*, *forwards*, or *backwards*?");
					String input37 = Direction6check.nextLine();
					
					if(input37.equalsIgnoreCase("Left"))
						left = true;
					if(input37.equalsIgnoreCase("Right"))
						right = true;
					if(input37.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input37.equalsIgnoreCase("Backwards"))
						backwards = true;
					
					if(right == true)
					{
						System.out.println("You went to the normal square on your right.");
						placement = 28;
						trace = 1;
					}
					if(left == true)
					{
						System.out.println("You went to your starting square on your left.");
						placement = 1;
						trace = 2;
					}
					if(forwards == true)
					{
						System.out.println("You went to the normal square ahead of you.");
						placement = 4;
						trace = 3;
					}
					if(backwards == true)
					{
						placement = 3;
						System.out.println("You went to the normal square behind you.");
						trace = 4;
					}
				}
				else if(trace == 4)
				{
					System.out.println("In all directions are normal squares execpt for your right, which is your starting square.");
					System.out.println("Will you go *right*, *left*, *forwards*, or *backwards*?");
					String input37 = Direction6check.nextLine();
					
					if(input37.equalsIgnoreCase("Left"))
						left = true;
					if(input37.equalsIgnoreCase("Right"))
						right = true;
					if(input37.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input37.equalsIgnoreCase("Backwards"))
						backwards = true;
					
					if(right == true)
					{
						System.out.println("You went to your starting square on your right.");
						placement = 1;
						trace = 2;
					}
					if(left == true)
					{
						System.out.println("You went to the normal square on your left.");
						placement = 28;
						trace = 1;
					}
					if(forwards == true)
					{
						System.out.println("You went to the normal square ahead of you.");
						placement = 120;
						trace = 4;
					}
					if(backwards == true)
					{
						placement = 118;
						System.out.println("You went to the normal square behind you.");
						trace = 3;
					}
				}
				break;
			
			case 3:
				
				breath --;
				if(mbatterythisturn == true)
				{
					mbatterythisturn = false;
					battery --;
					System.out.println("Your battery is now at "+battery+"%.");
				}
				else
					mbatterythisturn = true;
				System.out.println("You have "+breath+" air left.");
				System.out.println("Both behind and in front of you are normal squares.");
				System.out.println("Will you go *forwards* or *backwards*?");
				if(trace == 4)
				{
					String input38 = Direction7check.nextLine();
					
					if(input38.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input38.equalsIgnoreCase("Backwards"))
						backwards = true;
					
					if(forwards == true)
					{
						System.out.println("You went to the normal square ahead of you.");
						placement = 19;
						trace = 4;
					}
					if(backwards == true)
					{
						placement = 2;
						System.out.println("You went to the normal square behind you.");
						trace = 3;
					}
					
				}
				else if(trace == 3)
				{
					String input38 = Direction7check.nextLine();
					
					if(input38.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input38.equalsIgnoreCase("Backwards"))
						backwards = true;
					
					if(forwards == true)
					{
						System.out.println("You went to the normal square ahead of you.");
						placement = 2;
						trace = 3;
					}
					if(backwards == true)
					{
						placement = 19;
						System.out.println("You went to the normal square behind you.");
						trace = 4;
					}
				}
				
				break;
				
			case 4:
				
				breath --;
				if(mbatterythisturn == true)
				{
					mbatterythisturn = false;
					battery --;
					System.out.println("Your battery is now at "+battery+"%.");
				}
				else
					mbatterythisturn = true;
				System.out.println("You have "+breath+" air left.");
				System.out.println("Both behind and in front of you are normal squares.");
				System.out.println("Will you go *forwards* or *backwards*?");
				String input39 = Direction8check.nextLine();
				
				if(input39.equalsIgnoreCase("Forwards"))
					forwards = true;
				if(input39.equalsIgnoreCase("Backwards"))
					backwards = true;
				if(trace == 4)
				{
					if(forwards == true)
					{
						System.out.println("You went to the normal square ahead of you.");
						placement = 2;
						trace = 4;
					}
					if(backwards == true)
					{
						placement = 5;
						System.out.println("You went to the normal square behind you.");
						trace = 3;
					}
					
				}
				else if(trace == 3)
				{
					if(forwards == true)
					{
						System.out.println("You went to the normal square ahead of you.");
						placement = 5;
						trace = 3;
					}
					if(backwards == true)
					{
						placement = 2;
						System.out.println("You went to the normal square behind you.");
						trace = 4;
					}
				}
				
				break;
				
			case 5:
				
				breath --;
				if(mbatterythisturn == true)
				{
					mbatterythisturn = false;
					battery --;
					System.out.println("Your battery is now at "+battery+"%.");
				}
				else
					mbatterythisturn = true;
				System.out.println("You have "+breath+" air left.");
				if(trace == 1)
				{
					System.out.println("To your left and right are normal squares. Behind you is an air pocket.");
					System.out.println("Will you go *right*, *left*, or *backwards*?");
					String input40 = Direction9check.nextLine();
					
					if(input40.equalsIgnoreCase("Left"))
						left = true;
					if(input40.equalsIgnoreCase("Right"))
						right = true;
					if(input40.equalsIgnoreCase("Backwards"))
						backwards = true;
					
					if(left == true)
					{
						System.out.println("You went to the normal square to your left.");
						placement = 7;
						trace = 3;
					}
					if(right == true)
					{
						System.out.println("You went to the normal square to your right.");
						placement = 4;
						trace = 4;
					}
					if(backwards == true)
					{
						placement = 6;
						System.out.println("You went to the air pocket behind you.");
						trace = 2;
					}
					
				}
				else if(trace == 3)
				{
					System.out.println("In front and behind you are normal squares, with an air pocket to your left.");
					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
					String input40 = Direction9check.nextLine();
					
					if(input40.equalsIgnoreCase("Left"))
						left = true;
					if(input40.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input40.equalsIgnoreCase("Backwards"))
						backwards = true;
					
					if(left == true)
					{
						System.out.println("You went to the air pocket on your left.");
						placement = 6;
						trace = 2;
					}
					if(forwards == true)
					{
						System.out.println("You went to the normal square ahead of you.");
						placement = 7;
						trace = 3;
					}
					if(backwards == true)
					{
						placement = 4;
						System.out.println("You went to the normal square behind you.");
						trace = 4;
					}
				}
				
				else if(trace == 4)
				{
					System.out.println("In front and behind you are normal squares, with an air pocket to your right.");
					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
					String input40 = Direction9check.nextLine();
					
					if(input40.equalsIgnoreCase("Right"))
						right = true;
					if(input40.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input40.equalsIgnoreCase("Backwards"))
						backwards = true;
					
					if(right == true)
					{
						System.out.println("You went to the air pocket on your right.");
						placement = 6;
						trace = 2;
					}
					if(forwards == true)
					{
						System.out.println("You went to the normal square ahead of you.");
						placement = 4;
						trace = 4;
					}
					if(backwards == true)
					{
						placement = 7;
						System.out.println("You went to the normal square behind you.");
						trace = 3;
					}
				}
				
			break;
				
			case 6:
				
				breath = 12;
				if(mbatterythisturn == true)
				{
					mbatterythisturn = false;
					battery --;
					System.out.println("Your battery is now at "+battery+"%.");
				}
				else
					mbatterythisturn = true;
				
				System.out.println("You fully replenished your air supply!");
				System.out.println("You have "+breath+" air remaining.");
				System.out.println("Your only option for movement is backwards.");
				System.out.println("Press Enter to go backwards.");
				
				left = true;

				trace = 1;
				Direction10check.nextLine();
				
				placement = 5;
				
			break;
			
			case 7:
				
				breath --;
				if(mbatterythisturn == true)
				{
					mbatterythisturn = false;
					battery --;
					System.out.println("Your battery is now at "+battery+"%.");
				}
				else
					mbatterythisturn = true;
				System.out.println("You have "+breath+" air left.");
				if(trace == 2)
				{
					System.out.println("Both behind you and to your left are normal squares.");
					System.out.println("Will you go *left* or *backwards*?");
					String input42 = Direction11check.nextLine();
					
					if(input42.equalsIgnoreCase("Left"))
						left = true;
					if(input42.equalsIgnoreCase("Backwards"))
						backwards = true;
					
					if(left == true)
					{
						System.out.println("You went to the normal square to your left.");
						placement = 5;
						trace = 4;
					}
					if(backwards == true)
					{
						placement = 8;
						System.out.println("You went to the normal square behind you.");
						trace = 1;
					}
					
				}
				else if(trace == 3)
				{
					System.out.println("Both behind you and to your right are normal squares.");
					System.out.println("Will you go *right* or *backwards*?");
					String input42 = Direction11check.nextLine();
					
					if(input42.equalsIgnoreCase("Right"))
						right = true;
					if(input42.equalsIgnoreCase("Backwards"))
						backwards = true;
					
					if(right == true)
					{
						System.out.println("You went to the normal square to your right.");
						placement = 8;
						trace = 1;
					}
					if(backwards == true)
					{
						placement = 5;
						System.out.println("You went to the normal square behind you.");
						trace = 4;
					}
				}
				
				break;
			
                    case 8:
				
				breath --;
				if(mbatterythisturn == true)
				{
					mbatterythisturn = false;
					battery --;
					System.out.println("Your battery is now at "+battery+"%.");
				}
				else
					mbatterythisturn = true;
				System.out.println("You have "+breath+" air left.");
				System.out.println("Both behind and in front of you are normal squares.");
				System.out.println("Will you go *forwards* or *backwards*?");
				String input43 = Direction12check.nextLine();
					
				if(input43.equalsIgnoreCase("Forwards"))
					forwards = true;
				if(input43.equalsIgnoreCase("Backwards"))
					backwards = true;
                    
				if(trace == 1)
				{
					
					if(forwards == true)
					{
						System.out.println("You went to the normal square ahead of you.");
						placement = 9;
						trace = 1;
					}
					if(backwards == true)
					{
						placement = 7;
						System.out.println("You went to the normal square behind you.");
						trace = 2;
					}
					
				}
				else if(trace == 2)
				{
					
					if(forwards == true)
					{
						System.out.println("You went to the normal square ahead of you.");
						placement = 7;
						trace = 2;
					}
					if(backwards == true)
					{
						placement = 9;
						System.out.println("You went to the normal square behind you.");
						trace = 1;
					}
				}
				
				break;
                    
                case 9:
				
				breath --;
				if(mbatterythisturn == true)
				{
					mbatterythisturn = false;
					battery --;
					System.out.println("Your battery is now at "+battery+"%.");
				}
				else
					mbatterythisturn = true;
				System.out.println("You have "+breath+" air left.");
				if(trace == 1)
				{
					System.out.println("Both behind you and to your left are normal squares.");
					System.out.println("Will you go *left* or *backwards*?");
					String input44 = Direction13check.nextLine();
					
					if(input44.equalsIgnoreCase("Left"))
						left = true;
					if(input44.equalsIgnoreCase("Backwards"))
						backwards = true;
					
					if(left == true)
					{
						System.out.println("You went to the normal square to your left.");
						placement = 19;
						trace = 3;
					}
					if(backwards == true)
					{
						placement = 8;
						System.out.println("You went to the normal square behind you.");
						trace = 2;
					}
					
				}
				else if(trace == 4)
				{
					System.out.println("Both behind you and to your right are normal squares.");
					System.out.println("Will you go *right* or *backwards*?");
					String input44 = Direction13check.nextLine();
					
					if(input44.equalsIgnoreCase("Right"))
						right = true;
					if(input44.equalsIgnoreCase("Backwards"))
						backwards = true;
					
					if(right == true)
					{
						System.out.println("You went to the normal square to your right.");
						placement = 8;
						trace = 2;
					}
					if(backwards == true)
					{
						placement = 10;
						System.out.println("You went to the normal square behind you.");
						trace = 3;
					}
				}
				
				break;
				
                case 10:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 2)
    				{
    					System.out.println("To your right is an air pocket. Behind you and to your left are normal squares.");
    					System.out.println("Will you go *right*, *left*, or *backwards*?");
    					String input45 = Direction14check.nextLine();
    					
    					if(input45.equalsIgnoreCase("Left"))
    						left = true;
    					if(input45.equalsIgnoreCase("Right"))
    						right = true;
    					if(input45.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 9;
    						trace = 4;
    					}
    					if(right == true)
    					{
    						System.out.println("You went to the air pocket to your right.");
    						placement = 11;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 12;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("In front of you is an air pocket, and to your right and behind you are normal squares.");
    					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
    					String input45 = Direction14check.nextLine();
    					
    					if(input45.equalsIgnoreCase("Right"))
    						right = true;
    					if(input45.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input45.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square on your right.");
    						placement = 12;
    						trace = 1;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the air pocket ahead of you.");
    						placement = 11;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 9;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				else if(trace == 4)
    				{
    					System.out.println("In front of you and to your left are normal squares, with an air pocket behind you.");
    					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
    					String input45 = Direction14check.nextLine();
    					
    					if(input45.equalsIgnoreCase("Left"))
    						left = true;
    					if(input45.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input45.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square on your left.");
    						placement = 12;
    						trace = 1;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 9;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 11;
    						System.out.println("You went to the air pocket behind you.");
    						trace = 3;
    					}
    				}
    				
    			break;
                    
                case 11:
    				
    				breath = 12;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				
    				System.out.println("You fully replenished your air supply!");
    				System.out.println("You have "+breath+" air remaining.");
    				System.out.println("Your only option for movement is backwards.");
    				System.out.println("Press Enter to go backwards.");
    				
    				left = true;

    				trace = 4;
    				Direction15check.nextLine();
    				
    				placement = 10;
    				
    			break;
    			
                case 12:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input47 = Direction16check.nextLine();
    					
    				if(input47.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input47.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 13;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 10;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 10;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 13;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
    				
                case 13:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input48 = Direction17check.nextLine();
    					
    				if(input48.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input48.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 14;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 12;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 12;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 14;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    				
    				break;
    				
                case 14:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 1)
    				{
    					System.out.println("Both behind you and to your right are normal squares.");
    					System.out.println("Will you go *right* or *backwards*?");
    					String input49 = Direction18check.nextLine();
    					
    					if(input49.equalsIgnoreCase("Right"))
    						right = true;
    					if(input49.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square to your right.");
    						placement = 15;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 13;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("Both behind and to your left are normal squares.");
    					System.out.println("Will you go *left* or *backwards*?");
    					String input49 = Direction18check.nextLine();
    					
    					if(input49.equalsIgnoreCase("Left"))
    						left = true;
    					if(input49.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 13;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 15;
    						System.out.println("You went to the normal square in front of you.");
    						trace = 4;
    					}
    				}
    			
    				break;
    			
                case 15:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 4)
    				{
    					System.out.println("In front and behind you are normal squares. To your left is an air pocket.");
    					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
    					String input50 = Direction19check.nextLine();
    					
    					if(input50.equalsIgnoreCase("Left"))
    						left = true;
    					if(input50.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input50.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the air pocket to your left.");
    						placement = 15;
    						trace = 1;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square in front of you.");
    						placement = 17;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 14;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("In front and behind you are normal squares, with an air pocket to your right.");
    					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
    					String input50 = Direction19check.nextLine();
    					
    					if(input50.equalsIgnoreCase("Right"))
    						right = true;
    					if(input50.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input50.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the air pocket on your right.");
    						placement = 16;
    						trace = 1;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 14;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 17;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				else if(trace == 2)
    				{
    					System.out.println("To your right and left are normal squares. Behind you is an air pocket.");
    					System.out.println("Will you go *left*, *right*, or *backwards*?");
    					String input50 = Direction19check.nextLine();
    					
    					if(input50.equalsIgnoreCase("Right"))
    						right = true;
    					if(input50.equalsIgnoreCase("Left"))
    						left = true;
    					if(input50.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square on your right.");
    						placement = 14;
    						trace = 3;
    					}
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 17;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 16;
    						System.out.println("You went to the air pocket behind you.");
    						trace = 1;
    					}
    				}
    				
    			break;
    				
                case 16:
    				
    				breath = 12;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				
    				System.out.println("You fully replenished your air supply!");
    				System.out.println("You have "+breath+" air remaining.");
    				System.out.println("Your only option for movement is backwards.");
    				System.out.println("Press Enter to go backwards.");
    				
    				left = true;

    				trace = 2;
    				Direction20check.nextLine();
    				
    				placement = 15;
    				
    			break;
    			
                case 17:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input52 = Direction21check.nextLine();
					
					if(input52.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input52.equalsIgnoreCase("Backwards"))
						backwards = true;
					
    				if(trace == 4)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 18;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 15;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 15;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 18;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 18:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input53 = Direction8check.nextLine();
					
					if(input53.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input53.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 33;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 17;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 17;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 33;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 19:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input54 = Direction23check.nextLine();
					
					if(input54.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input54.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 20;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 3;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 3;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 20;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 20:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input55 = Direction24check.nextLine();
					
					if(input55.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input55.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 21;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 19;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 19;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 21;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 21:
        			
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 1)
    				{
    					System.out.println("In all directions are normal squares, except for your right, which is an air pocket.");
    					System.out.println("Will you go *right*, *left*, *forwards*, or *backwards*?");
    					String input56 = Direction25check.nextLine();
    					
    					if(input56.equalsIgnoreCase("Left"))
    						left = true;
    					if(input56.equalsIgnoreCase("Right"))
    						right = true;
    					if(input56.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input56.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the air pocket.");
    						placement = 22;
    						trace = 4;
    					}
    					if(left == true)
    					{
    						System.out.println("You went to the square to your left.");
    						placement = 20;
    						trace = 3;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the square ahead of you.");
    						placement = 23;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 34;
    						System.out.println("You went to the square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					System.out.println("In all directions are normal squares, except for your left, which is an air pocket.");
    					System.out.println("Will you go *right*, *left*, *forwards*, or *backwards*?");
    					String input56 = Direction25check.nextLine();
    					
    					if(input56.equalsIgnoreCase("Left"))
    						left = true;
    					if(input56.equalsIgnoreCase("Right"))
    						right = true;
    					if(input56.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input56.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the air pocket.");
    						placement = 22;
    						trace = 4;
    					}
    					if(right == true)
    					{
    						System.out.println("You went to the square to your right.");
    						placement = 20;
    						trace = 3;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the square ahead of you.");
    						placement = 34;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 23;
    						System.out.println("You went to the square behind you.");
    						trace = 1;
    					}

    				}
    				else if(trace == 3)
    				{
    					System.out.println("In all directions are normal squares, except for behind you, which is an air pocket.");
    					System.out.println("Will you go *right*, *left*, *forwards*, or *backwards*?");
    					String input56 = Direction25check.nextLine();
    					
    					if(input56.equalsIgnoreCase("Left"))
    						left = true;
    					if(input56.equalsIgnoreCase("Right"))
    						right = true;
    					if(input56.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input56.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square on your right.");
    						placement = 23;
    						trace = 1;
    					}
    					if(left == true)
    					{
    						System.out.println("You went to the normal square on your left.");
    						placement = 34;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						System.out.println("You went to the air pocket behind you.");
    						placement = 22;
    						trace = 4;
    					}
    					if(forwards == true)
    					{
    						placement = 20;
    						System.out.println("You went to the normal square ahead of you.");
    						trace = 3;
    					}
    				}
    				else if(trace == 4)
    				{
    					System.out.println("In all directions are normal squares, except in front of you, which is an air pocket.");
    					System.out.println("Will you go *right*, *left*, *forwards*, or *backwards*?");
    					String input56 = Direction25check.nextLine();
    					
    					if(input56.equalsIgnoreCase("Left"))
    						left = true;
    					if(input56.equalsIgnoreCase("Right"))
    						right = true;
    					if(input56.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input56.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square on your right.");
    						placement = 34;
    						trace = 2;
    					}
    					if(left == true)
    					{
    						System.out.println("You went to the normal square on your left.");
    						placement = 23;
    						trace = 1;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the air pocket ahead of you.");
    						placement = 22;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 20;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    				}
    				
    				break;
    				
                case 22:
    				
    				breath = 12;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				
    				System.out.println("You fully replenished your air supply!");
    				System.out.println("You have "+breath+" air remaining.");
    				System.out.println("Your only option for movement is backwards.");
    				System.out.println("Press Enter to go backwards.");
    				
    				left = true;

    				trace = 3;
    				Direction25check.nextLine();
    				
    				placement = 21;
    				
    			break;
    			
                case 23:
    				
			breath --;
			if(mbatterythisturn == true)
			{
				mbatterythisturn = false;
				battery --;
				System.out.println("Your battery is now at "+battery+"%.");
			}
			else
				mbatterythisturn = true;
			System.out.println("You have "+breath+" air left.");
			System.out.println("Both behind and in front of you are normal squares.");
			System.out.println("Will you go *forwards* or *backwards*?");
			String input57 = Direction20check.nextLine();
				
			if(input57.equalsIgnoreCase("Forwards"))
				forwards = true;
			if(input57.equalsIgnoreCase("Backwards"))
				backwards = true;
                
			if(trace == 1)
			{
				
				if(forwards == true)
				{
					System.out.println("You went to the normal square ahead of you.");
					placement = 24;
					trace = 1;
				}
				if(backwards == true)
				{
					placement = 21;
					System.out.println("You went to the normal square behind you.");
					trace = 2;
				}
				
			}
			else if(trace == 2)
			{
				
				if(forwards == true)
				{
					System.out.println("You went to the normal square ahead of you.");
					placement = 21;
					trace = 2;
				}
				if(backwards == true)
				{
					placement = 24;
					System.out.println("You went to the normal square behind you.");
					trace = 1;
				}
			}
			
                case 24:
    				
				breath --;
				if(mbatterythisturn == true)
				{
					mbatterythisturn = false;
					battery --;
					System.out.println("Your battery is now at "+battery+"%.");
				}
				else
					mbatterythisturn = true;
				System.out.println("You have "+breath+" air left.");
				if(trace == 1)
				{
					System.out.println("Both behind you and to your left are normal squares.");
					System.out.println("Will you go *left* or *backwards*?");
					String input58 = Direction22check.nextLine();
					
					if(input58.equalsIgnoreCase("Left"))
						left = true;
					if(input58.equalsIgnoreCase("Backwards"))
						backwards = true;
					
					if(left == true)
					{
						System.out.println("You went to the normal square to your left.");
						placement = 25;
						trace = 3;
					}
					if(backwards == true)
					{
						placement = 23;
						System.out.println("You went to the normal square behind you.");
						trace = 2;
					}
					
				}
				else if(trace == 4)
				{
					System.out.println("Both behind you and to your right are normal squares.");
					System.out.println("Will you go *right* or *backwards*?");
					String input58 = Direction22check.nextLine();
					
					if(input58.equalsIgnoreCase("Right"))
						right = true;
					if(input58.equalsIgnoreCase("Backwards"))
						backwards = true;
					
					if(right == true)
					{
						System.out.println("You went to the normal square to your right.");
						placement = 23;
						trace = 2;
					}
					if(backwards == true)
					{
						placement = 25;
						System.out.println("You went to the normal square behind you.");
						trace = 3;
					}
				}
				
				break;
				
                case 25:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input59 = Direction26check.nextLine();
					
					if(input59.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input59.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 24;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 26;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 26;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 24;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 26:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input60 = Direction27check.nextLine();
					
					if(input60.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input60.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 25;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 27;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 27;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 25;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 27:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input61 = Direction28check.nextLine();
					
					if(input61.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input61.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 26;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 29;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 29;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 26;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 28:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input62 = Direction29check.nextLine();
    					
    				if(input62.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input62.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 29;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 2;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 2;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 29;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
    				
                case 29:
        			
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 1)
    				{
    					System.out.println("In all directions except your left are normal squares.");
    					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
    					String input63 = Direction30check.nextLine();
    					
    					if(input63.equalsIgnoreCase("Right"))
    						right = true;
    					if(input63.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input63.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the square to your right.");
    						placement = 27;
    						trace = 4;
    					}
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the square ahead of you.");
    						placement = 29;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 28;
    						System.out.println("You went to the square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					System.out.println("In all directions except your right are normal squares.");
    					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
    					String input63 = Direction30check.nextLine();
    					
    					if(input63.equalsIgnoreCase("Left"))
    						left = true;
    					if(input63.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input63.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the square to your left.");
    						placement = 27;
    						trace = 4;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the square ahead of you.");
    						placement = 28;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 29;
    						System.out.println("You went to the square behind you.");
    						trace = 1;
    					}

    				}
    				else if(trace == 3)
    				{
    					System.out.println("In all directions except ahead of you are normal squares.");
    					System.out.println("Will you go *right*, *left*, or *backwards*?");
    					String input63 = Direction30check.nextLine();
    					
    					if(input63.equalsIgnoreCase("Left"))
    						left = true;
    					if(input63.equalsIgnoreCase("Right"))
    						right = true;
    					if(input63.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square on your right.");
    						placement = 30;
    						trace = 1;
    					}
    					if(left == true)
    					{
    						System.out.println("You went to the normal square on your left.");
    						placement = 28;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						System.out.println("You went to the normal square behind you.");
    						placement = 27;
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 30:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input64 = Direction31check.nextLine();
    					
    				if(input64.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input64.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 31;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 29;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 29;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 31;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
    				
                case 31:
        			
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 1)
    				{
    					System.out.println("In front of and behind you are normal squares, with an air pocket to your right.");
    					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
    					String input65 = Direction32check.nextLine();
    					
    					if(input65.equalsIgnoreCase("Right"))
    						right = true;
    					if(input65.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input65.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the air pocket to your right.");
    						placement = 32;
    						trace = 4;
    					}
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the square ahead of you.");
    						placement = 33;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 30;
    						System.out.println("You went to the square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					System.out.println("In front of and behind you are normal squares, with an air pocket to your left.");
    					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
    					String input65 = Direction32check.nextLine();
    					
    					if(input65.equalsIgnoreCase("Left"))
    						left = true;
    					if(input65.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input65.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the air pocket to your left.");
    						placement = 32;
    						trace = 4;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the square ahead of you.");
    						placement = 30;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 33;
    						System.out.println("You went to the square behind you.");
    						trace = 1;
    					}

    				}
    				else if(trace == 3)
    				{
    					System.out.println("To your right and left are normal squares, with an air pocket behind you.");
    					System.out.println("Will you go *right*, *left*, or *backwards*?");
    					String input65 = Direction32check.nextLine();
    					
    					if(input65.equalsIgnoreCase("Left"))
    						left = true;
    					if(input65.equalsIgnoreCase("Right"))
    						right = true;
    					if(input65.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square on your right.");
    						placement = 33;
    						trace = 1;
    					}
    					if(left == true)
    					{
    						System.out.println("You went to the normal square on your left.");
    						placement = 30;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						System.out.println("You went to the air pocket behind you.");
    						placement = 32;
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 32:
    				
    				breath = 12;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				
    				System.out.println("You fully replenished your air supply!");
    				System.out.println("You have "+breath+" air remaining.");
    				System.out.println("Your only option for movement is backwards.");
    				System.out.println("Press Enter to go backwards.");
    				
    				left = true;

    				trace = 3;
    				Direction33check.nextLine();
    				
    				placement = 31;
    				
    			break;
    			
                case 33:
        			
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 1)
    				{
    					System.out.println("In all directions except your right are normal squares.");
    					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
    					String input67 = Direction34check.nextLine();
    					
    					if(input67.equalsIgnoreCase("Left"))
    						left = true;
    					if(input67.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input67.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 18;
    						trace = 3;
    					}
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the square ahead of you.");
    						placement = 42;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 31;
    						System.out.println("You went to the square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					System.out.println("In all directions except your right are normal squares.");
    					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
    					String input67 = Direction34check.nextLine();
    					
    					if(input67.equalsIgnoreCase("Right"))
    						right = true;
    					if(input67.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input67.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square to your right.");
    						placement = 18;
    						trace = 3;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the square ahead of you.");
    						placement = 31;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 42;
    						System.out.println("You went to the square behind you.");
    						trace = 1;
    					}

    				}
    				else if(trace == 4)
    				{
    					System.out.println("In all directions except in front of you are normal squares.");
    					System.out.println("Will you go *right*, *left*, or *backwards*?");
    					String input67 = Direction34check.nextLine();
    					
    					if(input67.equalsIgnoreCase("Left"))
    						left = true;
    					if(input67.equalsIgnoreCase("Right"))
    						right = true;
    					if(input67.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square on your right.");
    						placement = 31;
    						trace = 2;
    					}
    					if(left == true)
    					{
    						System.out.println("You went to the normal square on your left.");
    						placement = 42;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						System.out.println("You went to the normal square behind you.");
    						placement = 18;
    						trace = 3;
    					}
    				}
    				
    				break;
    				
                case 34:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input68 = Direction35check.nextLine();
    					
    				if(input68.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input68.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 21;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 35;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 35;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 21;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
    				
                case 35:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input69 = Direction36check.nextLine();
    				//nice
    				if(input69.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input69.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 34;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 36;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 36;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 34;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
    				
                case 36:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 2)
    				{
    					System.out.println("Both behind you and to your left are normal squares.");
    					System.out.println("Will you go *left* or *backwards*?");
    					String input70 = Direction37check.nextLine();
    					
    					if(input70.equalsIgnoreCase("Left"))
    						left = true;
    					if(input70.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 37;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 35;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("Both behind you and to your right are normal squares.");
    					System.out.println("Will you go *right* or *backwards*?");
    					String input70 = Direction37check.nextLine();
    					
    					if(input70.equalsIgnoreCase("Right"))
    						right = true;
    					if(input70.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square to your right.");
    						placement = 35;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 37;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 37:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input71 = Direction38check.nextLine();
					
					if(input71.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input71.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 38;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 36;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 36;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 38;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 38:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input72 = Direction39check.nextLine();
					
					if(input72.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input72.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 39;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 37;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 37;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 38;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
    			case 39:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 1)
    				{
    					System.out.print("To your left is a normal square, behind you is an air pocket, and to your right a.");
    					if(fouro == false)
    						System.out.println("n unswitched switch.");
    					if(fouro == true)
    						System.out.println(" switched switch.");
    					System.out.println("Will you go *right*, *left*, or *backwards*?");
    					String input73 = Direction40check.nextLine();
    					
    					if(input73.equalsIgnoreCase("Left"))
    						left = true;
    					if(input73.equalsIgnoreCase("Right"))
    						right = true;
    					if(input73.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 38;
    						trace = 3;
    					}
    					if(right == true)
    					{
    						System.out.println("You went to the switch to your right.");
    						placement = 40;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 41;
    						System.out.println("You went to the air pocket behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("In front of you is a normal square, with an air pocket to your left, and a switched switch behind you.");
    					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
    					String input73 = Direction40check.nextLine();
    					
    					if(input73.equalsIgnoreCase("Left"))
    						left = true;
    					if(input73.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input73.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the air pocket on your left.");
    						placement = 41;
    						trace = 2;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 38;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 40;
    						System.out.println("You went to the switch behind you.");
    						trace = 4;
    					}
    				}
    				
    				else if(trace == 4)
    				{
    					System.out.print("Behind you is a normal square, with an air pocket to your right and a");
    					if(fouro == false)
    						System.out.println("n unswitched switch.");
    					if(fouro == true)
    						System.out.println(" switched switch.");
    					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
    					String input73 = Direction40check.nextLine();
    					
    					if(input73.equalsIgnoreCase("Right"))
    						right = true;
    					if(input73.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input73.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the air pocket on your right.");
    						placement = 41;
    						trace = 2;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the switch ahead of you.");
    						placement = 40;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 38;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    				}
    				
    			break;
    			
    			case 40:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(fouro == true)
    				{
    					System.out.println("You returned to the switch. You can't recall why you wanted to come here.");
    				}
    				else
    				{
    					if(sixfour == true)
    					{
    						System.out.println("You heard a distant rumbling.");
    						System.out.println("GROUP 1 BLOCKS OPENED!");
    						seveno = true;
    						sevenone = true;
    					}
    					else
    					{
    						System.out.println("You approached the mechanism. It consisted of a single lever. You pulled it. Little else happened.");
    					}
    				}
    				
    				fouro = true;
    				
    				System.out.println("Your only option for movement is backwards.");
    				System.out.println("Press Enter to go backwards.");
    				
    				left = true;

    				trace = 3;
    				Direction41check.nextLine();
    				
    				placement = 31;
    				
    				break;
    				
                case 41:
    				
    				breath = 12;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				
    				System.out.println("You fully replenished your air supply!");
    				System.out.println("You have "+breath+" air remaining.");
    				System.out.println("Your only option for movement is backwards.");
    				System.out.println("Press Enter to go backwards.");
    				
    				left = true;

    				trace = 1;
    				Direction42check.nextLine();
    				
    				placement = 39;
    				
    			break;
    			
                case 42:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input76 = Direction43check.nextLine();
    					
    				if(input76.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input76.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 43;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 33;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 33;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 43;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
    				
                case 43:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input77 = Direction44check.nextLine();
    					
    				if(input77.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input77.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 44;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 42;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 42;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 44;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
    				
                case 44:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 1)
    				{
    					System.out.println("In all directions except in front of you are normal squares.");
    					System.out.println("Will you go *right*, *left*, or *backwards*?");
    					String input78 = Direction45check.nextLine();
    					
    					if(input78.equalsIgnoreCase("Left"))
    						left = true;
    					if(input78.equalsIgnoreCase("Right"))
    						right = true;
    					if(input78.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 48;
    						trace = 3;
    					}
    					if(right == true)
    					{
    						System.out.println("You went to the normal square to your right.");
    						placement = 45;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 43;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("In all directions except your right are normal squares.");
    					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
    					String input78 = Direction45check.nextLine();
    					
    					if(input78.equalsIgnoreCase("Left"))
    						left = true;
    					if(input78.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input78.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square on your left.");
    						placement = 43;
    						trace = 2;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 48;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 45;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				else if(trace == 4)
    				{
    					System.out.println("In all directions except your left are normal squares.");
    					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
    					String input78 = Direction45check.nextLine();
    					
    					if(input78.equalsIgnoreCase("Right"))
    						right = true;
    					if(input78.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input78.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square on your right.");
    						placement = 43;
    						trace = 2;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 45;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 48;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    				}
    				
    			break;
    			
                case 45:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input79 = Direction46check.nextLine();
					
					if(input79.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input79.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 46;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 44;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 44;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 46;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 46:
    				
				breath --;
				if(mbatterythisturn == true)
				{
					mbatterythisturn = false;
					battery --;
					System.out.println("Your battery is now at "+battery+"%.");
				}
				else
					mbatterythisturn = true;
				System.out.println("You have "+breath+" air left.");
				if(trace == 1)
				{
					System.out.println("To your left is a normal square, and behind you is an air pocket.");
					System.out.println("Will you go *left* or *backwards*?");
					String input80 = Direction47check.nextLine();
					
					if(input80.equalsIgnoreCase("Left"))
						left = true;
					if(input80.equalsIgnoreCase("Backwards"))
						backwards = true;
					
					if(left == true)
					{
						System.out.println("You went to the normal square to your left.");
						placement = 45;
						trace = 3;
					}
					if(backwards == true)
					{
						placement = 47;
						System.out.println("You went to the air pocket behind you.");
						trace = 2;
					}
					
				}
				else if(trace == 4)
				{
					System.out.println("Behind you is a normal quare, with an air pocket to your right.");
					System.out.println("Will you go *right* or *backwards*?");
					String input80 = Direction47check.nextLine();
					
					if(input80.equalsIgnoreCase("Right"))
						right = true;
					if(input80.equalsIgnoreCase("Backwards"))
						backwards = true;
					
					if(right == true)
					{
						System.out.println("You went to the air pocket to your right.");
						placement = 47;
						trace = 2;
					}
					if(backwards == true)
					{
						placement = 45;
						System.out.println("You went to the normal square behind you.");
						trace = 3;
					}
				}
				
				break;
				
                case 47:
    				
    				breath = 12;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				
    				System.out.println("You fully replenished your air supply!");
    				System.out.println("You have "+breath+" air remaining.");
    				System.out.println("Your only option for movement is backwards.");
    				System.out.println("Press Enter to go backwards.");
    				
    				left = true;

    				trace = 1;
    				Direction48check.nextLine();
    				
    				placement = 46;
    				
    			break;
    			
                case 48:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input82 = Direction49check.nextLine();
					
					if(input82.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input82.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 44;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 49;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 49;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 44;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 49:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 2)
    				{
    					System.out.println("Both behind you and to your left are normal squares.");
    					System.out.println("Will you go *left* or *backwards*?");
    					String input83 = Direction50check.nextLine();
    					
    					if(input83.equalsIgnoreCase("Left"))
    						left = true;
    					if(input83.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 48;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 50;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("Both behind you and to your right are normal squares.");
    					System.out.println("Will you go *right* or *backwards*?");
    					String input83 = Direction50check.nextLine();
    					
    					if(input83.equalsIgnoreCase("Right"))
    						right = true;
    					if(input83.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square to your right.");
    						placement = 50;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 48;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 50:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input84 = Direction51check.nextLine();
    					
    				if(input84.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input84.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 51;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 49;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 49;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 51;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
    				
                case 51:
        			
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 1)
    				{
    					System.out.println("In all directions except your left are normal squares.");
    					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
    					String input85 = Direction52check.nextLine();
    					
    					if(input85.equalsIgnoreCase("Right"))
    						right = true;
    					if(input85.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input85.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the square to your right.");
    						placement = 52;
    						trace = 4;
    					}
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the square ahead of you.");
    						placement = 67;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 50;
    						System.out.println("You went to the square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					System.out.println("In all directions except your right are normal squares.");
    					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
    					String input85 = Direction52check.nextLine();
    					
    					if(input85.equalsIgnoreCase("Left"))
    						left = true;
    					if(input85.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input85.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the square to your left.");
    						placement = 52;
    						trace = 4;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the square ahead of you.");
    						placement = 50;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 67;
    						System.out.println("You went to the square behind you.");
    						trace = 1;
    					}

    				}
    				else if(trace == 3)
    				{
    					System.out.println("In all directions except ahead of you are normal squares.");
    					System.out.println("Will you go *right*, *left*, or *backwards*?");
    					String input85 = Direction52check.nextLine();
    					
    					if(input85.equalsIgnoreCase("Left"))
    						left = true;
    					if(input85.equalsIgnoreCase("Right"))
    						right = true;
    					if(input85.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square on your right.");
    						placement = 67;
    						trace = 1;
    					}
    					if(left == true)
    					{
    						System.out.println("You went to the normal square on your left.");
    						placement = 50;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						System.out.println("You went to the normal square behind you.");
    						placement = 52;
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 52:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input86 = Direction53check.nextLine();
					
					if(input86.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input86.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 53;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 51;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 51;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 53;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 53:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input87 = Direction54check.nextLine();
					
					if(input87.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input87.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 54;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 52;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 52;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 54;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 54:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 4)
    				{
    					System.out.println("In front and behind you are normal squares. To your left is an air pocket.");
    					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
    					String input88 = Direction55check.nextLine();
    					
    					if(input88.equalsIgnoreCase("Left"))
    						left = true;
    					if(input88.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input88.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the air pocket to your left.");
    						placement = 55;
    						trace = 1;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square in front of you.");
    						placement = 56;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 53;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("In front and behind you are normal squares, with an air pocket to your right.");
    					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
    					String input88 = Direction55check.nextLine();
    					
    					if(input88.equalsIgnoreCase("Right"))
    						right = true;
    					if(input88.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input88.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the air pocket on your right.");
    						placement = 55;
    						trace = 1;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 53;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 56;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				else if(trace == 2)
    				{
    					System.out.println("To your right and left are normal squares. Behind you is an air pocket.");
    					System.out.println("Will you go *left*, *right*, or *backwards*?");
    					String input88 = Direction55check.nextLine();
    					
    					if(input88.equalsIgnoreCase("Right"))
    						right = true;
    					if(input88.equalsIgnoreCase("Left"))
    						left = true;
    					if(input88.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square on your right.");
    						placement = 53;
    						trace = 3;
    					}
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 56;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 55;
    						System.out.println("You went to the air pocket behind you.");
    						trace = 1;
    					}
    				}
    				
    			break;
    			
                case 55:
    				
    				breath = 12;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				
    				System.out.println("You fully replenished your air supply!");
    				System.out.println("You have "+breath+" air remaining.");
    				System.out.println("Your only option for movement is backwards.");
    				System.out.println("Press Enter to go backwards.");
    				
    				left = true;

    				trace = 2;
    				Direction56check.nextLine();
    				
    				placement = 54;
    				
    			break;
    			
                case 56:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input90 = Direction57check.nextLine();
					
					if(input90.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input90.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 57;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 54;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 54;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 57;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 57:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input91 = Direction58check.nextLine();
					
					if(input91.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input91.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 58;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 56;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 56;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 58;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 58:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input92 = Direction59check.nextLine();
					
					if(input92.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input92.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 59;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 57;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 57;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 59;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 59:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 4)
    				{
    					System.out.println("In all directions except your right are normal squares.");
    					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
    					String input93 = Direction60check.nextLine();
    					
    					if(input93.equalsIgnoreCase("Left"))
    						left = true;
    					if(input93.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input93.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 65;
    						trace = 1;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square in front of you.");
    						placement = 60;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 58;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("In all directions except your left are normal squares.");
    					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
    					String input93 = Direction60check.nextLine();
    					
    					if(input93.equalsIgnoreCase("Right"))
    						right = true;
    					if(input93.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input93.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square on your right.");
    						placement = 65;
    						trace = 1;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 58;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 60;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				else if(trace == 2)
    				{
    					System.out.println("In all directions except in front of you are normal squares.");
    					System.out.println("Will you go *left*, *right*, or *backwards*?");
    					String input93 = Direction60check.nextLine();
    					
    					if(input93.equalsIgnoreCase("Right"))
    						right = true;
    					if(input93.equalsIgnoreCase("Left"))
    						left = true;
    					if(input93.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square on your right.");
    						placement = 58;
    						trace = 3;
    					}
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 60;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 65;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    				
    			break;
    			
    			case 60:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 1)
    				{
    					System.out.println("To your left and right are normal squares. Behind you is an air pocket.");
    					System.out.println("Will you go *right*, *left*, or *backwards*?");
    					String input94 = Direction61check.nextLine();
    					
    					if(input94.equalsIgnoreCase("Left"))
    						left = true;
    					if(input94.equalsIgnoreCase("Right"))
    						right = true;
    					if(input94.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 59;
    						trace = 3;
    					}
    					if(right == true)
    					{
    						System.out.println("You went to the normal square to your right.");
    						placement = 62;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 61;
    						System.out.println("You went to the air pocket behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("In front and behind you are normal squares, with an air pocket to your left.");
    					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
    					String input94 = Direction61check.nextLine();
    					
    					if(input94.equalsIgnoreCase("Left"))
    						left = true;
    					if(input94.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input94.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the air pocket on your left.");
    						placement = 61;
    						trace = 2;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 59;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 62;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				else if(trace == 4)
    				{
    					System.out.println("In front and behind you are normal squares, with an air pocket to your right.");
    					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
    					String input94 = Direction61check.nextLine();
    					
    					if(input94.equalsIgnoreCase("Right"))
    						right = true;
    					if(input94.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input94.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the air pocket on your right.");
    						placement = 61;
    						trace = 2;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 62;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 59;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    				}
    				
    			break;
    			
    			 case 61:
     				
     				breath = 12;
     				if(mbatterythisturn == true)
     				{
     					mbatterythisturn = false;
     					battery --;
     					System.out.println("Your battery is now at "+battery+"%.");
     				}
     				else
     					mbatterythisturn = true;
     				
     				System.out.println("You fully replenished your air supply!");
     				System.out.println("You have "+breath+" air remaining.");
     				System.out.println("Your only option for movement is backwards.");
     				System.out.println("Press Enter to go backwards.");
     				
     				left = true;

     				trace = 1;
     				Direction62check.nextLine();
     				
     				placement = 60;
     				
     			break;
     			
                 case 62:
     				
     				breath --;
     				if(mbatterythisturn == true)
     				{
     					mbatterythisturn = false;
     					battery --;
     					System.out.println("Your battery is now at "+battery+"%.");
     				}
     				else
     					mbatterythisturn = true;
     				System.out.println("You have "+breath+" air left.");
     				System.out.println("Both behind and in front of you are normal squares.");
     				System.out.println("Will you go *forwards* or *backwards*?");
 					String input96 = Direction63check.nextLine();
 					
 					if(input96.equalsIgnoreCase("Forwards"))
 						forwards = true;
 					if(input96.equalsIgnoreCase("Backwards"))
 						backwards = true;
     				if(trace == 4)
     				{
     					if(forwards == true)
     					{
     						System.out.println("You went to the normal square ahead of you.");
     						placement = 63;
     						trace = 4;
     					}
     					if(backwards == true)
     					{
     						placement = 60;
     						System.out.println("You went to the normal square behind you.");
     						trace = 3;
     					}
     					
     				}
     				else if(trace == 3)
     				{
     					if(forwards == true)
     					{
     						System.out.println("You went to the normal square ahead of you.");
     						placement = 60;
     						trace = 3;
     					}
     					if(backwards == true)
     					{
     						placement = 63;
     						System.out.println("You went to the normal square behind you.");
     						trace = 4;
     					}
     				}
     				
     				break;
     				
                 case 63:
      				
      				breath --;
      				if(mbatterythisturn == true)
      				{
      					mbatterythisturn = false;
      					battery --;
      					System.out.println("Your battery is now at "+battery+"%.");
      				}
      				else
      					mbatterythisturn = true;
      				System.out.println("You have "+breath+" air left.");
      				if(trace == 4)
      				{
      					System.out.print("Behind you is a normal square, and in ront of you is a");
      					if(sixfour == true)
      						System.out.println(" switched switch.");
      					else
      						System.out.println("n unswitched switch.");
      				}
      				
      				System.out.println("Will you go *forwards* or *backwards*?");
  					String input97 = Direction64check.nextLine();
  					
  					if(input97.equalsIgnoreCase("Forwards"))
  						forwards = true;
  					if(input97.equalsIgnoreCase("Backwards"))
  						backwards = true;
      				if(trace == 4)
      				{
      					if(forwards == true)
      					{
      						System.out.println("You went to the switch ahead of you.");
      						placement = 64;
      						trace = 4;
      					}
      					if(backwards == true)
      					{
      						placement = 62;
      						System.out.println("You went to the normal square behind you.");
      						trace = 3;
      					}
      					
      				}
      				else if(trace == 3)
      				{
      					if(forwards == true)
      					{
      						System.out.println("You went to the normal square ahead of you.");
      						placement = 62;
      						trace = 3;
      					}
      					if(backwards == true)
      					{
      						placement = 64;
      						System.out.println("You went to the switch behind you.");
      						trace = 4;
      					}
      				}
      				
      				break;
      				
    			case 64:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(sixfour == true)
    				{
    					System.out.println("You returned to the switch. You can't recall why you wanted to come here.");
    				}
    				else
    				{
    					if(fouro == true)
    					{
    						System.out.println("You heard a distant rumbling.");
    						System.out.println("GROUP 1 BLOCKS OPENED!");
    						seveno = true;
    						sevenone = true;
    					}
    					else
    					{
    						System.out.println("You approached the mechanism. It consisted of a single lever. You pulled it. Little else happened.");
    					}
    				}
    				
    				sixfour = true;
    				
    				System.out.println("Your only option for movement is backwards.");
    				System.out.println("Press Enter to go backwards.");
    				
    				left = true;

    				trace = 3;
    				Direction65check.nextLine();
    				
    				placement = 63;
    				
    				break;
    				
                case 65:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input99 = Direction66check.nextLine();
    					
    				if(input99.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input99.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 66;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 59;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 59;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 66;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
    				
                case 66:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(sevenone = false)
    				{
    					System.out.println("In front of you lay a block. It is impassable. Behind you is a normal square.");
    					System.out.println("Your only option for movement is backwards.");
         				System.out.println("Press Enter to go backwards.");
         				left = true;

         				trace = 2;
         				Direction67check.nextLine();
         				
         				placement = 65;
         				
    				}
    				else if (sevenone = true)
    				{
    					System.out.println("In front of you lay an open block. Behind you is a normal square.");
    					System.out.println("Will you go *forwards* or *backwards*?");
    					String input100 = Direction67check.nextLine();
        				
    	    			if(input100.equalsIgnoreCase("Forwards"))
    	    				forwards = true;
    	    			if(input100.equalsIgnoreCase("Backwards"))
    	    				backwards = true;
    	                        
    	    			if(forwards == true)
    	    			{
    	    				System.out.println("You went to the block ahead of you.");
    	    				placement = 71;
    	    				trace = 1;
    	    			}
    	    			if(backwards == true)
    	    			{
    	    				placement = 65;
    	    				System.out.println("You went to the normal square behind you.");
    	    				trace = 2;
    					}
    				}
    	
    				break;
    				
                case 67:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input101 = Direction68check.nextLine();
    					
    				if(input101.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input101.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 68;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 51;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 51;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 68;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
    				
                case 68:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 1)
    				{
    					System.out.println("Both behind you and to your right are normal squares.");
    					System.out.println("Will you go *right* or *backwards*?");
    					String input102 = Direction69check.nextLine();
    					//nice
    					
    					if(input102.equalsIgnoreCase("Right"))
    						right = true;
    					if(input102.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square to your right.");
    						placement = 69;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 67;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("Both behind and to your left are normal squares.");
    					System.out.println("Will you go *left* or *forwards*?");
    					String input102 = Direction69check.nextLine();
    					
    					if(input102.equalsIgnoreCase("Left"))
    						left = true;
    					if(input102.equalsIgnoreCase("Backwards"))
    						forwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 67;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 69;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    			
    				break;
    				
                case 69: //nice
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				if(trace == 2)
    				{
    					System.out.println("Behind you is an open block. To your right is a normal square.");
    					System.out.println("Will you go *right* or *backwards*?");
    					String input103 = Direction70check.nextLine();
    					
    					if(input103.equalsIgnoreCase("Right"))
    						left = true;
    					if(input103.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square to your right.");
    						placement = 68;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 70;
    						System.out.println("You went to the block behind you.");
    						trace = 1;
    					}
    					
    				}
    				else if(trace == 4)
    				{
    					if(seveno == true)
    					{
    						System.out.println("To your left is an open block. Behind you is a normal square.");
    						System.out.println("Will you go *left* or *backwards?");
    						String input103 = Direction70check.nextLine();
    	    				
    	    				if(input103.equalsIgnoreCase("Left"))
    	    					left = true;
    	    				if(input103.equalsIgnoreCase("Backwards"))
    	    					backwards = true;
    	    				
    	    				if(left == true)
    	    				{
    	    					System.out.println("You went to the block to your left.");
    	    					placement = 70;
    	    					trace = 1;
    	    				}
    	    				if(backwards == true)
    	    				{
    	    					placement = 68;
    	    					System.out.println("You went to the normal square behind you.");
    	    					trace = 3;
    	    				}
    					}
    					else
    					{
    						System.out.println("To your left is a closed block. Behind you is a normal square.");
    						System.out.println("Your only option for movement is backwards.");
    	    				System.out.println("Press Enter to go backwards.");
    	    				
    	    				left = true;

    	    				trace = 3;
    	    				Direction70check.nextLine();
    	    				
    	    				placement = 68;
    					}
    				}
    				
    				break;
    				
                case 70:
                	
                	if(passo == false)
                	{
                		passo = true;
                		System.out.println("As you passed through the block, the water got darker. You sensed a feeling of doom.");
                	}
                	else
                	{}
             
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input104 = Direction71check.nextLine();
    					
    				if(input104.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input104.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 72;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 69;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 69;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 72;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
    				
                case 71:
                	
                	if(passo == false)
                	{
                		passo = true;
                		System.out.println("As you passed through the block, the water got darker. You sensed a feeling of doom.");
                	}
                	else
                	{}
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input105 = Direction72check.nextLine();
    					
    				if(input105.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input105.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 122;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 66;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 66;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 122;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
    				
                case 72:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 1)
    				{
    					System.out.print("To your left is a normal square. Behind you is an open block. To your right is a");
    					if(seventhree == true)
    						System.out.println(" switched switch.");
    					else
    						System.out.println("n unswitched switch.");
    					System.out.println("Will you go *right*, *left*, or *backwards*?");
    					String input106 = Direction73check.nextLine();
    					
    					if(input106.equalsIgnoreCase("Left"))
    						left = true;
    					if(input106.equalsIgnoreCase("Right"))
    						right = true;
    					if(input106.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 74;
    						trace = 3;
    					}
    					if(right == true)
    					{
    						System.out.println("You went to the switch to your right.");
    						placement = 73;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 70;
    						System.out.println("You went to the open block behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.print("Ahead of you is a normal square. To your left is an open block, and behind you a switched switch.");
    					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
    					String input106 = Direction73check.nextLine();
    					
    					if(input106.equalsIgnoreCase("Left"))
    						left = true;
    					if(input106.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input106.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the open block on your left.");
    						placement = 70;
    						trace = 2;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 74;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 73;
    						System.out.println("You went to the switch behind you.");
    						trace = 4;
    					}
    				}
    				
    				else if(trace == 4)
    				{
    					System.out.print("To your right is an open block. Behind you is a normal block, and in front of you is a");
    					if(seventhree == true)
    						System.out.println(" switched switch.");
    					else
    						System.out.println("n unswitched switch.");
    					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
    					String input106 = Direction73check.nextLine();
    					
    					if(input106.equalsIgnoreCase("Right"))
    						right = true;
    					if(input106.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input106.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the open block on your right.");
    						placement = 70;
    						trace = 2;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the switch ahead of you.");
    						placement = 73;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 74;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    				}
    				
    			break;
    			
    			case 73:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(seventhree == true)
    				{
    					System.out.println("You returned to the switch. You can't recall why you wanted to come here.");
    				}
    				else
    				{
    					if((ninenine == true)&&(onetwosix == true))
    					{
    						System.out.println("You heard a distant rumbling.");
    						System.out.println("GROUP 2 BLOCK OPENED!");
    						onethreeo = true;
    					}
    					else
    					{
    						System.out.println("You approached the mechanism. It consisted of a single lever. You pulled it. Little else happened.");
    					}
    				}
    				
    				seventhree = true;
    				
    				System.out.println("Your only option for movement is backwards.");
    				System.out.println("Press Enter to go backwards.");
    				
    				left = true;

    				trace = 3;
    				Direction74check.nextLine();
    				
    				placement = 72;
    				
    				break;
    				
                case 74:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input108 = Direction75check.nextLine();
					
					if(input108.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input108.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 72;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 75;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 75;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 72;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 75:
        			
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 1)
    				{
    					System.out.println("In front of you and to your right are normal squares. Behind you is an air pocket");
    					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
    					String input109 = Direction76check.nextLine();
    					
    					if(input109.equalsIgnoreCase("Right"))
    						right = true;
    					if(input109.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input109.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the square to your right.");
    						placement = 74;
    						trace = 4;
    					}
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the square ahead of you.");
    						placement = 77;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 76;
    						System.out.println("You went to the air pocket behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					System.out.println("Behind you and to your left are normal squares. In front of you is an air pocket.");
    					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
    					String input109 = Direction76check.nextLine();
    					if(input109.equalsIgnoreCase("Left"))
    						left = true;
    					if(input109.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input109.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the square to your left.");
    						placement = 74;
    						trace = 4;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the air pocket ahead of you.");
    						placement = 76;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 77;
    						System.out.println("You went to the square behind you.");
    						trace = 1;
    					}

    				}
    				else if(trace == 3)
    				{
    					System.out.println("Behind you and to your right are normal squares. To your left is an air pocket.");
    					System.out.println("Will you go *right*, *left*, or *backwards*?");
    					String input109 = Direction76check.nextLine();
    					
    					if(input109.equalsIgnoreCase("Left"))
    						left = true;
    					if(input109.equalsIgnoreCase("Right"))
    						right = true;
    					if(input109.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square on your right.");
    						placement = 77;
    						trace = 1;
    					}
    					if(left == true)
    					{
    						System.out.println("You went to the air pocket on your left.");
    						placement = 75;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						System.out.println("You went to the normal square behind you.");
    						placement = 74;
    						trace = 4;
    					}
    				}
    				
    				break;
    				
    			case 76:
    				
    				breath = 12;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				
    				System.out.println("You fully replenished your air supply!");
    				System.out.println("You have "+breath+" air remaining.");
    				System.out.println("Your only option for movement is backwards.");
    				System.out.println("Press Enter to go backwards.");
    				
    				left = true;

    				trace = 1;
    				Direction77check.nextLine();
    				
    				placement = 75;
    				
    			break;
    			
                case 77:
        			
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 1)
    				{
    					System.out.println("In all directions except your right are normal squares.");
    					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
    					String input111 = Direction78check.nextLine();
    					
    					if(input111.equalsIgnoreCase("Left"))
    						left = true;
    					if(input111.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input111.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the square to your left.");
    						placement = 85;
    						trace = 3;
    					}
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the square ahead of you.");
    						placement = 78;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 75;
    						System.out.println("You went to the square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					System.out.println("In all directions except your left are normal squares.");
    					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
    					String input111 = Direction78check.nextLine();
    					
    					if(input111.equalsIgnoreCase("Right"))
    						right = true;
    					if(input111.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input111.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the square to your right.");
    						placement = 85;
    						trace = 3;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the square ahead of you.");
    						placement = 75;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 78;
    						System.out.println("You went to the square behind you.");
    						trace = 1;
    					}

    				}
    				else if(trace == 4)
    				{
    					System.out.println("In all directions except ahead of you are normal squares.");
    					System.out.println("Will you go *right*, *left*, or *backwards*?");
    					String input111 = Direction30check.nextLine();
    					
    					if(input111.equalsIgnoreCase("Left"))
    						left = true;
    					if(input111.equalsIgnoreCase("Right"))
    						right = true;
    					if(input111.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square on your right.");
    						placement = 75;
    						trace = 2;
    					}
    					if(left == true)
    					{
    						System.out.println("You went to the normal square on your left.");
    						placement = 78;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						System.out.println("You went to the normal square behind you.");
    						placement = 85;
    						trace = 3;
    					}
    				}
    				
    				break;
    				
                case 78:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 1)
    				{
    					System.out.println("Both behind you and to your right are normal squares.");
    					System.out.println("Will you go *right* or *backwards*?");
    					String input112 = Direction79check.nextLine();
    					
    					if(input112.equalsIgnoreCase("Right"))
    						right = true;
    					if(input112.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square to your right.");
    						placement = 79;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 77;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("Both behind and to your left are normal squares.");
    					System.out.println("Will you go *left* or *forwards*?");
    					String input112 = Direction79check.nextLine();
    					
    					if(input112.equalsIgnoreCase("Left"))
    						left = true;
    					if(input112.equalsIgnoreCase("Backwards"))
    						forwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 77;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 79;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    			
    				break;
    				
                case 79:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input113 = Direction80check.nextLine();
					
					if(input113.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input113.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 80;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 78;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 78;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 80;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 80:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input114 = Direction81check.nextLine();
					
					if(input114.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input114.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 81;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 79;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 79;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 81;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 81:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 2)
    				{
    					System.out.println("To your left is an air pocket. Behind you and to your right are normal squares.");
    					System.out.println("Will you go *right*, *left*, or *backwards*?");
    					String input115 = Direction82check.nextLine();
    					
    					if(input115.equalsIgnoreCase("Left"))
    						left = true;
    					if(input115.equalsIgnoreCase("Right"))
    						right = true;
    					if(input115.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the air pocket to your left.");
    						placement = 82;
    						trace = 4;
    					}
    					if(right == true)
    					{
    						System.out.println("You went to the normal square to your right.");
    						placement = 80;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 83;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("Behind you is an air pocket, and to your right and in front of you are normal squares.");
    					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
    					String input115 = Direction82check.nextLine();
    					
    					if(input115.equalsIgnoreCase("Right"))
    						right = true;
    					if(input115.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input115.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square on your right.");
    						placement = 83;
    						trace = 1;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 80;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 82;
    						System.out.println("You went to the air pocket behind you.");
    						trace = 4;
    					}
    				}
    				
    				else if(trace == 4)
    				{
    					System.out.println("In front of you is an air pocket. Behind you and to your left are normal squares.");
    					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
    					String input115 = Direction81check.nextLine();
    					
    					if(input115.equalsIgnoreCase("Left"))
    						left = true;
    					if(input115.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input115.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square on your left.");
    						placement = 83;
    						trace = 1;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the air pocket ahead of you.");
    						placement = 82;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 80;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    				}
    				
    			break;
    			
                case 82:
    				
    				breath = 12;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				
    				System.out.println("You fully replenished your air supply!");
    				System.out.println("You have "+breath+" air remaining.");
    				System.out.println("Your only option for movement is backwards.");
    				System.out.println("Press Enter to go backwards.");
    				
    				left = true;

    				trace = 3;
    				Direction83check.nextLine();
    				
    				placement = 81;
    				
    			break;
    			
                case 83:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input116 = Direction84check.nextLine();
    					
    				if(input116.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input116.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 84;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 81;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 81;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 84;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
    				
                case 84:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input117 = Direction84check.nextLine();
    					
    				if(input117.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input117.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 116;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 83;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 83;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 116;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
    				
                case 85:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input118 = Direction86check.nextLine();
					
					if(input118.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input118.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 77;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 86;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 86;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 77;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 86:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input119 = Direction87check.nextLine();
					
					if(input119.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input119.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 85;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 87;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 87;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 85;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 87:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input120 = Direction88check.nextLine();
					
					if(input120.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input120.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 86;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 88;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 88;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 86;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 88:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input121 = Direction89check.nextLine();
					
					if(input121.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input121.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 87;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 89;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 89;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 87;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 89:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 4)
    				{
    					System.out.println("In front and behind you are normal squares. To your left is an air pocket.");
    					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
    					String input122 = Direction90check.nextLine();
    					
    					if(input122.equalsIgnoreCase("Left"))
    						left = true;
    					if(input122.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input122.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the air pocket to your left.");
    						placement = 90;
    						trace = 1;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square in front of you.");
    						placement = 88;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 91;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("In front and behind you are normal squares, with an air pocket to your right.");
    					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
    					String input122 = Direction90check.nextLine();
    					
    					if(input122.equalsIgnoreCase("Right"))
    						right = true;
    					if(input122.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input122.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the air pocket on your right.");
    						placement = 90;
    						trace = 1;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 91;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 88;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				else if(trace == 2)
    				{
    					System.out.println("To your right and left are normal squares. Behind you is an air pocket.");
    					System.out.println("Will you go *left*, *right*, or *backwards*?");
    					String input122 = Direction90check.nextLine();
    					
    					if(input122.equalsIgnoreCase("Right"))
    						right = true;
    					if(input122.equalsIgnoreCase("Left"))
    						left = true;
    					if(input122.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square on your right.");
    						placement = 91;
    						trace = 3;
    					}
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 88;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 90;
    						System.out.println("You went to the air pocket behind you.");
    						trace = 1;
    					}
    				}
    				
    			break;
    			
                case 90:
    				
    				breath = 12;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				
    				System.out.println("You fully replenished your air supply!");
    				System.out.println("You have "+breath+" air remaining.");
    				System.out.println("Your only option for movement is backwards.");
    				System.out.println("Press Enter to go backwards.");
    				
    				left = true;

    				trace = 2;
    				Direction91check.nextLine();
    				
    				placement = 89;
    				
    			break;
    			
                case 91:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 1)
    				{
    					System.out.println("In all directions except in front of you are normal squares.");
    					System.out.println("Will you go *right*, *left*, or *backwards*?");
    					String input123 = Direction92check.nextLine();
    					
    					if(input123.equalsIgnoreCase("Left"))
    						left = true;
    					if(input123.equalsIgnoreCase("Right"))
    						right = true;
    					if(input123.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 100;
    						trace = 3;
    					}
    					if(right == true)
    					{
    						System.out.println("You went to the normal square to your right.");
    						placement = 89;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 92;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("In all directions except your right are normal squares.");
    					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
    					String input123 = Direction92check.nextLine();
    					
    					if(input123.equalsIgnoreCase("Left"))
    						left = true;
    					if(input123.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input123.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square on your left.");
    						placement = 92;
    						trace = 2;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 100;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 89;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				else if(trace == 4)
    				{
    					System.out.println("In all directions except your left are normal squares.");
    					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
    					String input123 = Direction92check.nextLine();
    					
    					if(input123.equalsIgnoreCase("Right"))
    						right = true;
    					if(input123.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input123.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square on your right.");
    						placement = 92;
    						trace = 2;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 89;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 100;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    				}
    				
    			break;
    			
                case 92:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input124 = Direction93check.nextLine();
    					
    				if(input124.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input124.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 91;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 93;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 93;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 91;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
    				
    			case 93:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 2)
    				{
    					System.out.println("Both behind you and to your left are normal squares.");
    					System.out.println("Will you go *left* or *backwards*?");
    					String input125 = Direction94check.nextLine();
    					
    					if(input125.equalsIgnoreCase("Left"))
    						left = true;
    					if(input125.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 94;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 92;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("Both behind you and to your right are normal squares.");
    					System.out.println("Will you go *right* or *backwards*?");
    					String input125 = Direction94check.nextLine();
    					
    					if(input125.equalsIgnoreCase("Right"))
    						right = true;
    					if(input125.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square to your right.");
    						placement = 92;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 94;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 94:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input126 = Direction95check.nextLine();
					
					if(input126.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input126.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 95;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 93;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 93;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 95;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 95:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 1)
    				{
    					System.out.println("Behind you and to your left are normal squares. To your right is an air pocket.");
    					System.out.println("Will you go *right*, *left*, or *backwards*?");
    					String input127 = Direction96check.nextLine();
    					
    					if(input127.equalsIgnoreCase("Left"))
    						left = true;
    					if(input127.equalsIgnoreCase("Right"))
    						right = true;
    					if(input127.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 194;
    						trace = 3;
    					}
    					if(right == true)
    					{
    						System.out.println("You went to the air pocket to your right.");
    						placement = 96;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 97;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("In front of you and to your left are normal squares. Behind you is an air pocket.");
    					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
    					String input127 = Direction96check.nextLine();
    					
    					if(input127.equalsIgnoreCase("Left"))
    						left = true;
    					if(input127.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input127.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square on your left.");
    						placement = 97;
    						trace = 2;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 94;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 96;
    						System.out.println("You went to the air pocket behind you.");
    						trace = 4;
    					}
    				}
    				
    				else if(trace == 4)
    				{
    					System.out.println("To your right and behind you are normal squares. In front of you is an air pocket.");
    					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
    					String input127 = Direction96check.nextLine();
    					
    					if(input127.equalsIgnoreCase("Right"))
    						right = true;
    					if(input127.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input127.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square on your right.");
    						placement = 97;
    						trace = 2;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the air pocket ahead of you.");
    						placement = 96;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 94;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    				}
    				
    			break;
    			
                case 96:
    				
    				breath = 12;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				
    				System.out.println("You fully replenished your air supply!");
    				System.out.println("You have "+breath+" air remaining.");
    				System.out.println("Your only option for movement is backwards.");
    				System.out.println("Press Enter to go backwards.");
    				
    				left = true;

    				trace = 3;
    				Direction97check.nextLine();
    				
    				placement = 95;
    				
    			break;
    			
                case 97:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input128 = Direction98check.nextLine();
    					
    				if(input128.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input128.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 95;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 98;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 98;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 95;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
    				
    			case 98:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 2)
    				{
    					System.out.print("Behind you is a normal square. To your left is a");
    					if(ninenine == false)
    						System.out.println("n unswitched switch");
    					if(ninenine == true)
    						System.out.println(" switched switch");
    					System.out.println("Will you go *left* or *backwards*?");
    					String input129 = Direction99check.nextLine();
    					
    					if(input129.equalsIgnoreCase("Left"))
    						left = true;
    					if(input129.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the switch to your left.");
    						placement = 99;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 97;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("To your right is a normal square. Behind you is a switched switch.");
    					System.out.println("Will you go *right* or *backwards*?");
    					String input129 = Direction99check.nextLine();
    					
    					if(input129.equalsIgnoreCase("Right"))
    						right = true;
    					if(input129.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square to your right.");
    						placement = 97;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 99;
    						System.out.println("You went to the switch behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
    			case 99:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(ninenine == true)
    				{
    					System.out.println("You returned to the switch. You can't recall why you wanted to come here.");
    				}
    				else
    				{
    					if((seventhree == true)&&(onetwosix == true))
    					{
    						System.out.println("You heard a distant rumbling.");
    						System.out.println("GROUP 2 BLOCK OPENED!");
    						onethreeo = true;
    					}
    					else
    					{
    						System.out.println("You approached the mechanism. It consisted of a single lever. You pulled it. Little else happened.");
    					}
    				}
    				
    				ninenine = true;
    				
    				System.out.println("Your only option for movement is backwards.");
    				System.out.println("Press Enter to go backwards.");
    				
    				left = true;

    				trace = 3;
    				Direction100check.nextLine();
    				//Check 100!!!
    				
    				placement = 78;
    				
    				break;
    				
    			case 100:
    				//Hooo boy. Only 30 blocks left! (Most of which are one directional!)
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 2)
    				{
    					System.out.println("Both behind you and to your left are normal squares.");
    					System.out.println("Will you go *left* or *backwards*?");
    					String input130 = Direction101check.nextLine();
    					
    					if(input130.equalsIgnoreCase("Left"))
    						left = true;
    					if(input130.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 91;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 101;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("Both behind you and to your right are normal squares.");
    					System.out.println("Will you go *right* or *backwards*?");
    					String input130 = Direction101check.nextLine();
    					
    					if(input130.equalsIgnoreCase("Right"))
    						right = true;
    					if(input130.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square to your right.");
    						placement = 101;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 91;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 101:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input131 = Direction102check.nextLine();
    					
    				if(input131.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input131.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 102;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 100;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 100;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 101;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
    				
                case 102:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input132 = Direction103check.nextLine();
    					
    				if(input132.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input132.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 103;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 101;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 101;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 103;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
    				
                case 103:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input133 = Direction104check.nextLine();
    					
    				if(input133.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input133.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 104;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 102;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 102;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 104;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
    				
                case 104:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 1)
    				{
    					System.out.println("Both behind you and to your right are normal squares.");
    					System.out.println("Will you go *right* or *backwards*?");
    					String input134 = Direction105check.nextLine();
    					
    					if(input134.equalsIgnoreCase("Right"))
    						right = true;
    					if(input134.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square to your right.");
    						placement = 105;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 103;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("Both behind and to your left are normal squares.");
    					System.out.println("Will you go *left* or *forwards*?");
    					String input134 = Direction105check.nextLine();
    					
    					if(input134.equalsIgnoreCase("Left"))
    						left = true;
    					if(input134.equalsIgnoreCase("Backwards"))
    						forwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 103;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 105;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    			
    				break;
    				
                case 105:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input135 = Direction106check.nextLine();
					
					if(input135.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input135.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 106;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 104;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 106;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 104;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 106:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input136 = Direction107check.nextLine();
					
					if(input136.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input136.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 107;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 105;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 105;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 107;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 107:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 4)
    				{
    					System.out.println("In front and behind you are normal squares. To your left is an air pocket.");
    					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
    					String input137 = Direction108check.nextLine();
    					
    					if(input137.equalsIgnoreCase("Left"))
    						left = true;
    					if(input137.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input137.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the air pocket to your left.");
    						placement = 108;
    						trace = 1;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square in front of you.");
    						placement = 109;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 106;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("In front and behind you are normal squares, with an air pocket to your right.");
    					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
    					String input137 = Direction108check.nextLine();
    					
    					if(input137.equalsIgnoreCase("Right"))
    						right = true;
    					if(input137.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input137.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the air pocket on your right.");
    						placement = 108;
    						trace = 1;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 106;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 109;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				else if(trace == 2)
    				{
    					System.out.println("To your right and left are normal squares. Behind you is an air pocket.");
    					System.out.println("Will you go *left*, *right*, or *backwards*?");
    					String input137 = Direction108check.nextLine();
    					
    					if(input137.equalsIgnoreCase("Right"))
    						right = true;
    					if(input137.equalsIgnoreCase("Left"))
    						left = true;
    					if(input137.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square on your right.");
    						placement = 106;
    						trace = 3;
    					}
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 109;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 108;
    						System.out.println("You went to the air pocket behind you.");
    						trace = 1;
    					}
    				}
    				
    			break;
    			
                case 108:
    				
    				breath = 12;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				
    				System.out.println("You fully replenished your air supply!");
    				System.out.println("You have "+breath+" air remaining.");
    				System.out.println("Your only option for movement is backwards.");
    				System.out.println("Press Enter to go backwards.");
    				
    				left = true;

    				trace = 2;
    				Direction109check.nextLine();
    				
    				placement = 107;
    				
    			break;
    			
                case 109:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input138 = Direction110check.nextLine();
					
					if(input138.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input138.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 110;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 107;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 107;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 110;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 110:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input139 = Direction111check.nextLine();
					
					if(input139.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input139.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 111;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 109;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 109;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 111;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 111:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input140 = Direction112check.nextLine();
					
					if(input140.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input140.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 112;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 110;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 110;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 112;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
                case 112:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
					String input141 = Direction113check.nextLine();
					
					if(input141.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input141.equalsIgnoreCase("Backwards"))
						backwards = true;
    				if(trace == 4)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 113;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 111;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 111;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 113;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				break;
    				
    			case 113:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 1)
    				{
    					System.out.println("To your left and right are normal squares. Behind you is an air pocket.");
    					System.out.println("Will you go *right*, *left*, or *backwards*?");
    					String input142 = Direction114check.nextLine();
    					
    					if(input142.equalsIgnoreCase("Left"))
    						left = true;
    					if(input142.equalsIgnoreCase("Right"))
    						right = true;
    					if(input142.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 112;
    						trace = 3;
    					}
    					if(right == true)
    					{
    						System.out.println("You went to the normal square to your right.");
    						placement = 115;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 114;
    						System.out.println("You went to the air pocket behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("In front and behind you are normal squares, with an air pocket to your left.");
    					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
    					String input142 = Direction114check.nextLine();
    					
    					if(input142.equalsIgnoreCase("Left"))
    						left = true;
    					if(input142.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input142.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the air pocket on your left.");
    						placement = 114;
    						trace = 2;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 112;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 115;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				else if(trace == 4)
    				{
    					System.out.println("In front and behind you are normal squares, with an air pocket to your right.");
    					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
    					String input142 = Direction114check.nextLine();
    					
    					if(input142.equalsIgnoreCase("Right"))
    						right = true;
    					if(input142.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input142.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the air pocket on your right.");
    						placement = 114;
    						trace = 2;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 115;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 112;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    				}
    				
    			break;
    			
    			 case 114:
     				
     				breath = 12;
     				if(mbatterythisturn == true)
     				{
     					mbatterythisturn = false;
     					battery --;
     					System.out.println("Your battery is now at "+battery+"%.");
     				}
     				else
     					mbatterythisturn = true;
     				
     				System.out.println("You fully replenished your air supply!");
     				System.out.println("You have "+breath+" air remaining.");
     				System.out.println("Your only option for movement is backwards.");
     				System.out.println("Press Enter to go backwards.");
     				
     				left = true;

     				trace = 1;
     				Direction115check.nextLine();
     				
     				placement = 113;
     				
     			break;
     			
                 case 115:
     				
     				breath --;
     				if(mbatterythisturn == true)
     				{
     					mbatterythisturn = false;
     					battery --;
     					System.out.println("Your battery is now at "+battery+"%.");
     				}
     				else
     					mbatterythisturn = true;
     				System.out.println("You have "+breath+" air left.");
     				System.out.println("Both behind and in front of you are normal squares.");
     				System.out.println("Will you go *forwards* or *backwards*?");
 					String input143 = Direction116check.nextLine();
 					
 					if(input143.equalsIgnoreCase("Forwards"))
 						forwards = true;
 					if(input143.equalsIgnoreCase("Backwards"))
 						backwards = true;
     				if(trace == 4)
     				{
     					if(forwards == true)
     					{
     						System.out.println("You went to the normal square ahead of you.");
     						placement = 116;
     						trace = 4;
     					}
     					if(backwards == true)
     					{
     						placement = 113;
     						System.out.println("You went to the normal square behind you.");
     						trace = 3;
     					}
     					
     				}
     				else if(trace == 3)
     				{
     					if(forwards == true)
     					{
     						System.out.println("You went to the normal square ahead of you.");
     						placement = 113;
     						trace = 3;
     					}
     					if(backwards == true)
     					{
     						placement = 116;
     						System.out.println("You went to the normal square behind you.");
     						trace = 4;
     					}
     				}
     				
     				break;
     				
                 case 116:
     				
     				breath --;
     				if(mbatterythisturn == true)
     				{
     					mbatterythisturn = false;
     					battery --;
     					System.out.println("Your battery is now at "+battery+"%.");
     				}
     				else
     					mbatterythisturn = true;
     				System.out.println("You have "+breath+" air left.");
     				if(trace == 1)
     				{
     					System.out.println("In all directions except in front of you are normal squares.");
     					System.out.println("Will you go *right*, *left*, or *backwards*?");
     					String input144 = Direction117check.nextLine();
     					
     					if(input144.equalsIgnoreCase("Left"))
     						left = true;
     					if(input144.equalsIgnoreCase("Right"))
     						right = true;
     					if(input144.equalsIgnoreCase("Backwards"))
     						backwards = true;
     					
     					if(left == true)
     					{
     						System.out.println("You went to the normal square to your left.");
     						placement = 115;
     						trace = 3;
     					}
     					if(right == true)
     					{
     						System.out.println("You went to the normal square to your right.");
     						placement = 117;
     						trace = 4;
     					}
     					if(backwards == true)
     					{
     						placement = 84;
     						System.out.println("You went to the normal square behind you.");
     						trace = 2;
     					}
     					
     				}
     				else if(trace == 3)
     				{
     					System.out.println("In all directions except your right are normal squares.");
     					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
     					String input144 = Direction117check.nextLine();
     					
     					if(input144.equalsIgnoreCase("Left"))
     						left = true;
     					if(input144.equalsIgnoreCase("Forwards"))
     						forwards = true;
     					if(input144.equalsIgnoreCase("Backwards"))
     						backwards = true;
     					
     					if(left == true)
     					{
     						System.out.println("You went to the normal square on your left.");
     						placement = 84;
     						trace = 2;
     					}
     					if(forwards == true)
     					{
     						System.out.println("You went to the normal square ahead of you.");
     						placement = 115;
     						trace = 3;
     					}
     					if(backwards == true)
     					{
     						placement = 117;
     						System.out.println("You went to the normal square behind you.");
     						trace = 4;
     					}
     				}
     				
     				else if(trace == 4)
     				{
     					System.out.println("In all directions except your left are normal squares.");
     					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
     					String input144 = Direction117check.nextLine();
     					
     					if(input144.equalsIgnoreCase("Right"))
     						right = true;
     					if(input144.equalsIgnoreCase("Forwards"))
     						forwards = true;
     					if(input144.equalsIgnoreCase("Backwards"))
     						backwards = true;
     					
     					if(right == true)
     					{
     						System.out.println("You went to the normal square on your right.");
     						placement = 84;
     						trace = 2;
     					}
     					if(forwards == true)
     					{
     						System.out.println("You went to the normal square ahead of you.");
     						placement = 117;
     						trace = 4;
     					}
     					if(backwards == true)
     					{
     						placement = 115;
     						System.out.println("You went to the normal square behind you.");
     						trace = 3;
     					}
     				}
     				
     			break;
     			
                 case 117:
     				
     				breath --;
     				if(mbatterythisturn == true)
     				{
     					mbatterythisturn = false;
     					battery --;
     					System.out.println("Your battery is now at "+battery+"%.");
     				}
     				else
     					mbatterythisturn = true;
     				System.out.println("You have "+breath+" air left.");
     				System.out.println("Both behind and in front of you are normal squares.");
     				System.out.println("Will you go *forwards* or *backwards*?");
 					String input145 = Direction118check.nextLine();
 					
 					if(input145.equalsIgnoreCase("Forwards"))
 						forwards = true;
 					if(input145.equalsIgnoreCase("Backwards"))
 						backwards = true;
     				if(trace == 4)
     				{
     					if(forwards == true)
     					{
     						System.out.println("You went to the normal square ahead of you.");
     						placement = 118;
     						trace = 4;
     					}
     					if(backwards == true)
     					{
     						placement = 116;
     						System.out.println("You went to the normal square behind you.");
     						trace = 3;
     					}
     					
     				}
     				else if(trace == 3)
     				{
     					if(forwards == true)
     					{
     						System.out.println("You went to the normal square ahead of you.");
     						placement = 116;
     						trace = 3;
     					}
     					if(backwards == true)
     					{
     						placement = 118;
     						System.out.println("You went to the normal square behind you.");
     						trace = 4;
     					}
     				}
     				
     				break;
     				
                 case 118:
      				
     				breath --;
     				if(mbatterythisturn == true)
     				{
     					mbatterythisturn = false;
     					battery --;
     					System.out.println("Your battery is now at "+battery+"%.");
     				}
     				else
     					mbatterythisturn = true;
     				System.out.println("You have "+breath+" air left.");
     				System.out.println("Both behind and in front of you are normal squares.");
     				System.out.println("Will you go *forwards* or *backwards*?");
 					String input146 = Direction119check.nextLine();
 					
 					if(input146.equalsIgnoreCase("Forwards"))
 						forwards = true;
 					if(input146.equalsIgnoreCase("Backwards"))
 						backwards = true;
     				if(trace == 4)
     				{
     					if(forwards == true)
     					{
     						System.out.println("You went to the normal square ahead of you.");
     						placement = 119;
     						trace = 4;
     					}
     					if(backwards == true)
     					{
     						placement = 117;
     						System.out.println("You went to the normal square behind you.");
     						trace = 3;
     					}
     					
     				}
     				else if(trace == 3)
     				{
     					if(forwards == true)
     					{
     						System.out.println("You went to the normal square ahead of you.");
     						placement = 117;
     						trace = 3;
     					}
     					if(backwards == true)
     					{
     						placement = 119;
     						System.out.println("You went to the normal square behind you.");
     						trace = 4;
     					}
     				}
     				
     				break;
                    
                 case 119:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 4)
    				{
    					System.out.println("In front and behind you are normal squares. To your left is an air pocket.");
    					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
    					String input147 = Direction120check.nextLine();
    					
    					if(input147.equalsIgnoreCase("Left"))
    						left = true;
    					if(input147.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input147.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(left == true)
    					{
    						System.out.println("You went to the air pocket to your left.");
    						placement = 120;
    						trace = 1;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square in front of you.");
    						placement = 121;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 118;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					System.out.println("In front and behind you are normal squares, with an air pocket to your right.");
    					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
    					String input147 = Direction120check.nextLine();
    					
    					if(input147.equalsIgnoreCase("Right"))
    						right = true;
    					if(input147.equalsIgnoreCase("Forwards"))
    						forwards = true;
    					if(input147.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the air pocket on your right.");
    						placement = 120;
    						trace = 1;
    					}
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 118;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 121;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    				
    				else if(trace == 2)
    				{
    					System.out.println("To your right and left are normal squares. Behind you is an air pocket.");
    					System.out.println("Will you go *left*, *right*, or *backwards*?");
    					String input147 = Direction120check.nextLine();
    					
    					if(input147.equalsIgnoreCase("Right"))
    						right = true;
    					if(input147.equalsIgnoreCase("Left"))
    						left = true;
    					if(input147.equalsIgnoreCase("Backwards"))
    						backwards = true;
    					
    					if(right == true)
    					{
    						System.out.println("You went to the normal square on your right.");
    						placement = 118;
    						trace = 3;
    					}
    					if(left == true)
    					{
    						System.out.println("You went to the normal square to your left.");
    						placement = 121;
    						trace = 4;
    					}
    					if(backwards == true)
    					{
    						placement = 120;
    						System.out.println("You went to the air pocket behind you.");
    						trace = 1;
    					}
    				}
    				
    			break;
                    
                case 120:
    				
    				breath = 12;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				
    				System.out.println("You fully replenished your air supply!");
    				System.out.println("You have "+breath+" air remaining.");
    				System.out.println("Your only option for movement is backwards.");
    				System.out.println("Press Enter to go backwards.");
    				
    				left = true;

    				trace = 2;
    				Direction121check.nextLine();
    				
    				placement = 119;
    				
    			break;
                    
                case 121:
      				
     				breath --;
     				if(mbatterythisturn == true)
     				{
     					mbatterythisturn = false;
     					battery --;
     					System.out.println("Your battery is now at "+battery+"%.");
     				}
     				else
     					mbatterythisturn = true;
     				System.out.println("You have "+breath+" air left.");
     				System.out.println("Both behind and in front of you are normal squares.");
     				System.out.println("Will you go *forwards* or *backwards*?");
 					String input148 = Direction122check.nextLine();
 					
 					if(input148.equalsIgnoreCase("Forwards"))
 						forwards = true;
 					if(input148.equalsIgnoreCase("Backwards"))
 						backwards = true;
     				if(trace == 4)
     				{
     					if(forwards == true)
     					{
     						System.out.println("You went to the normal square ahead of you.");
     						placement = 129;
     						trace = 4;
     					}
     					if(backwards == true)
     					{
     						placement = 119;
     						System.out.println("You went to the normal square behind you.");
     						trace = 3;
     					}
     					
     				}
     				else if(trace == 3)
     				{
     					if(forwards == true)
     					{
     						System.out.println("You went to the normal square ahead of you.");
     						placement = 119;
     						trace = 3;
     					}
     					if(backwards == true)
     					{
     						placement = 129;
     						System.out.println("You went to the normal square behind you.");
     						trace = 4;
     					}
     				}
     				
     				break;
                    
                case 122:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(trace == 1)
                        System.out.println("Behind you is an open block. In front of you is a normal square.");   
                    if(trace == 2)
                        System.out.println("Behind you is a normal square. In front of you is an open block.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input149 = Direction123check.nextLine();
    					
    				if(input149.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input149.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 123;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 71;
    						System.out.println("You went to the open block behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the open block ahead of you.");
    						placement = 71;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 123;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
                    
                case 123:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input150 = Direction124check.nextLine();
    					
    				if(input150.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input150.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 124;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 122;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 122;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 124;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
    				
                case 124:
			
				breath --;
				if(mbatterythisturn == true)
				{
					mbatterythisturn = false;
					battery --;
					System.out.println("Your battery is now at "+battery+"%.");
				}
				else
					mbatterythisturn = true;
				System.out.println("You have "+breath+" air left.");
				if(trace == 1)
				{
					System.out.print("In front of and behind you are normal squares. To your left is an air pocket and to your right a");
					if(onetwosix == false)
						System.out.println("n unswitched switch.");
					if(onetwosix == true)
						System.out.println(" switched switch.");
					System.out.println("Will you go *right*, *left*, *forwards*, or *backwards*?");
					String input151 = Direction125check.nextLine();
					
					if(input151.equalsIgnoreCase("Left"))
						left = true;
					if(input151.equalsIgnoreCase("Right"))
						right = true;
					if(input151.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input151.equalsIgnoreCase("Backwards"))
						backwards = true;
					
					if(left == true)
					{
						System.out.println("You went to the air pocket.");
						placement = 125;
						trace = 3;
					}
					if(right == true)
					{
						System.out.println("You went to the switch.");
						placement = 126;
						trace = 4;
					}
					if(forwards == true)
					{
						System.out.println("You went to the square ahead of you.");
						placement = 127;
						trace = 1;
					}
					if(backwards == true)
					{
						placement = 123;
						System.out.println("You went to the square behind you.");
						trace = 2;
					}
					
				}
				else if(trace == 2)
				{
					System.out.print("In front of and behind you are normal squares. To your right is an air pocket and to your left a");
					if(onetwosix == false)
						System.out.println("n unswitched switch.");
					if(onetwosix == true)
						System.out.println(" switched switch.");
					System.out.println("Will you go *right*, *left*, *forwards*, or *backwards*?");
					String input151 = Direction125check.nextLine();
					
					if(input151.equalsIgnoreCase("Left"))
						left = true;
					if(input151.equalsIgnoreCase("Right"))
						right = true;
					if(input151.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input151.equalsIgnoreCase("Backwards"))
						backwards = true;
					
					if(right == true)
					{
						System.out.println("You went to the air pocket.");
						placement = 125;
						trace = 3;
					}
					if(left == true)
					{
						System.out.println("You went to the switch.");
						placement = 126;
						trace = 4;
					}
					if(forwards == true)
					{
						System.out.println("You went to the square ahead of you.");
						placement = 123;
						trace = 2;
					}
					if(backwards == true)
					{
						placement = 127;
						System.out.println("You went to the square behind you.");
						trace = 1;
					}

				}
				else if(trace == 3)
				{
					System.out.print("In front of you is an air pocket, behind you, a switched switch, and to your left and right, normal squares.");
					System.out.println("Will you go *right*, *left*, *forwards*, or *backwards*?");
					String input151 = Direction125check.nextLine();
					
					if(input151.equalsIgnoreCase("Left"))
						left = true;
					if(input151.equalsIgnoreCase("Right"))
						right = true;
					if(input151.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input151.equalsIgnoreCase("Backwards"))
						backwards = true;
					
					if(right == true)
					{
						System.out.println("You went to the normal square on your right.");
						placement = 127;
						trace = 1;
					}
					if(left == true)
					{
						System.out.println("You went to the normal square on your left.");
						placement = 123;
						trace = 2;
					}
					if(forwards == true)
					{
						System.out.println("You went to the air pocket ahead of you.");
						placement = 125;
						trace = 3;
					}
					if(backwards == true)
					{
						placement = 124;
						System.out.println("You went to the switched switch behind you.");
						trace = 4;
					}
				}
				else if(trace == 4)
				{
					System.out.print("In front of you is a");
					if(onetwosix == false)
						System.out.print("n unswitched switch");
					if(onetwosix == true)
						System.out.print(" switched switch");
					System.out.println(", behind you an air pocket, and to your left and right, normal squares.");
					System.out.println("Will you go *right*, *left*, *forwards*, or *backwards*?");
					String input151 = Direction125check.nextLine();
					
					if(input151.equalsIgnoreCase("Left"))
						left = true;
					if(input151.equalsIgnoreCase("Right"))
						right = true;
					if(input151.equalsIgnoreCase("Forwards"))
						forwards = true;
					if(input151.equalsIgnoreCase("Backwards"))
						backwards = true;
					
					if(right == true)
					{
						System.out.println("You went to the normal square on your right.");
						placement = 123;
						trace = 2;
					}
					if(left == true)
					{
						System.out.println("You went to the normal square on your left.");
						placement = 127;
						trace = 1;
					}
					if(forwards == true)
					{
						System.out.println("You went to the switch ahead of you.");
						placement = 126;
						trace = 4;
					}
					if(backwards == true)
					{
						placement = 125;
						System.out.println("You went to the air pocket behind you.");
						trace = 3;
					}
				}
				
				break;
                    
                case 125:
    				
    				breath = 12;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				
    				System.out.println("You fully replenished your air supply!");
    				System.out.println("You have "+breath+" air remaining.");
    				System.out.println("Your only option for movement is backwards.");
    				System.out.println("Press Enter to go backwards.");
    				
    				left = true;

    				trace = 4;
    				Direction126check.nextLine();
    				
    				placement = 124;
    				
    			break;
                    
                case 126:
    				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				if(onetwosix == true)
    				{
    					System.out.println("You returned to the switch. You can't recall why you wanted to come here.");
    				}
    				else
    				{
    					if((seventhree == true)&&(ninenine == true))
    					{
    						System.out.println("You heard a distant rumbling.");
    						System.out.println("GROUP 2 BLOCK OPENED!");
    						onethreeo = true;
    					}
    					else
    					{
    						System.out.println("You approached the mechanism. It consisted of a single lever. You pulled it. Little else happened.");
    					}
    				}
    				
    				onetwosix = true;
    				
    				System.out.println("Your only option for movement is backwards.");
    				System.out.println("Press Enter to go backwards.");
    				
    				left = true;

    				trace = 3;
    				Direction127check.nextLine();
    				
    				placement = 124;
    				
    				break;
                    
                case 127:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input152 = Direction128check.nextLine();
    					
    				if(input152.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input152.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 124;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 128;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 124;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 128;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
                    
                case 128:
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input153 = Direction129check.nextLine();
    					
    				if(input153.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input153.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 1)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 129;
    						trace = 1;
    					}
    					if(backwards == true)
    					{
    						placement = 127;
    						System.out.println("You went to the normal square behind you.");
    						trace = 2;
    					}
    					
    				}
    				else if(trace == 2)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 127;
    						trace = 2;
    					}
    					if(backwards == true)
    					{
    						placement = 129;
    						System.out.println("You went to the normal square behind you.");
    						trace = 1;
    					}
    				}
    	
    				break;
    				
                case 129:
     				
    				breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				
    				if(onethreeo = false)
    				{
    					if(trace == 4)
    					{
    						System.out.println("In front of you lay a block. It is impassable. Behind you and to your right are normal squares.");
    						System.out.println("Will you go *right* or *backwards*?");
    						String input154 = Direction130check.nextLine();
    						
    						if(input154.equalsIgnoreCase("Right"))
    							right = true;
    						if(input154.equalsIgnoreCase("Backwards"))
    							backwards = true;
    						
    						if(right == true)
    						{
    							System.out.println("You went to the normal square to your right.");
    							placement = 128;
    							trace = 2;
    						}
    						if(backwards == true)
    						{
    							placement = 121;
    							System.out.println("You went to the normal square behind you.");
    							trace = 3;
    						}
    					
    					}
    					if(trace == 1)
    					{
    						System.out.println("To your right lay a block. It is impassable. Behind you and to your left are normal squares.");
    						System.out.println("Will you go *left* or *backwards*?");
    						String input154 = Direction130check.nextLine();
    						
    						if(input154.equalsIgnoreCase("Left"))
    							left = true;
    						if(input154.equalsIgnoreCase("Backwards"))
    							backwards = true;
    						
    						if(left == true)
    						{
    							System.out.println("You went to the normal square to your left.");
    							placement = 121;
    							trace = 3;
    						}
    						if(backwards == true)
    						{
    							placement = 128;
    							System.out.println("You went to the normal square behind you.");
    							trace = 2;
    						}
    					}
         				
    				}
    				else if (onethreeo = true)
    				{
    					if(trace == 1)
         				{
         					System.out.println("To your right lay an open block. Behind you and to your left are normal squares.");
         					System.out.println("Will you go *right*, *left*, or *backwards*?");
         					String input154 = Direction130check.nextLine();
         					
         					if(input154.equalsIgnoreCase("Left"))
         						left = true;
         					if(input154.equalsIgnoreCase("Right"))
         						right = true;
         					if(input154.equalsIgnoreCase("Backwards"))
         						backwards = true;
         					
         					if(left == true)
         					{
         						System.out.println("You went to the normal square to your left.");
         						placement = 121;
         						trace = 3;
         					}
         					if(right == true)
         					{
         						System.out.println("You went to the open block to your right.");
         						placement = 130;
         						trace = 4;
         					}
         					if(backwards == true)
         					{
         						placement = 128;
         						System.out.println("You went to the normal square behind you.");
         						trace = 2;
         					}
         					
         				}
         				else if(trace == 3)
         				{
         					System.out.println("Behind you lay an open block. To your left and in front of you are normal squares.");
         					System.out.println("Will you go *left*, *forwards*, or *backwards*?");
         					String input154 = Direction130check.nextLine();
         					
         					if(input154.equalsIgnoreCase("Left"))
         						left = true;
         					if(input154.equalsIgnoreCase("Forwards"))
         						forwards = true;
         					if(input154.equalsIgnoreCase("Backwards"))
         						backwards = true;
         					
         					if(left == true)
         					{
         						System.out.println("You went to the normal square on your left.");
         						placement = 128;
         						trace = 2;
         					}
         					if(forwards == true)
         					{
         						System.out.println("You went to the normal square ahead of you.");
         						placement = 121;
         						trace = 3;
         					}
         					if(backwards == true)
         					{
         						placement = 130;
         						System.out.println("You went to the open block behind you.");
         						trace = 4;
         					}
         				}
         				
         				else if(trace == 4)
         				{
         					System.out.println("In front of you lay an open block. Behind you and to your right are normal squares.");
         					System.out.println("Will you go *right*, *forwards*, or *backwards*?");
         					String input154 = Direction130check.nextLine();
         					
         					if(input154.equalsIgnoreCase("Right"))
         						right = true;
         					if(input154.equalsIgnoreCase("Forwards"))
         						forwards = true;
         					if(input154.equalsIgnoreCase("Backwards"))
         						backwards = true;
         					
         					if(right == true)
         					{
         						System.out.println("You went to the normal square on your right.");
         						placement = 128;
         						trace = 2;
         					}
         					if(forwards == true)
         					{
         						System.out.println("You went to the open block ahead of you.");
         						placement = 130;
         						trace = 4;
         					}
         					if(backwards == true)
         					{
         						placement = 121;
         						System.out.println("You went to the normal square behind you.");
         						trace = 3;
         					}
         				}
    					
    				}
    				
    			break;
    			
                case 130:
                	
                	if(passtwo == false)
                	{
                		passtwo = true;
                		System.out.println("As you passed through the block, the water got darker. You sensed a feeling of doom.");
                	}
                	else
                	{}
                	
                	breath --;
    				if(mbatterythisturn == true)
    				{
    					mbatterythisturn = false;
    					battery --;
    					System.out.println("Your battery is now at "+battery+"%.");
    				}
    				else
    					mbatterythisturn = true;
    				System.out.println("You have "+breath+" air left.");
    				System.out.println("Both behind and in front of you are normal squares.");
    				System.out.println("Will you go *forwards* or *backwards*?");
    				String input155 = Direction131check.nextLine();
    					
    				if(input155.equalsIgnoreCase("Forwards"))
    					forwards = true;
    				if(input155.equalsIgnoreCase("Backwards"))
    					backwards = true;
                        
    				if(trace == 4)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 131;
    					}
    					if(backwards == true)
    					{
    						placement = 129;
    						System.out.println("You went to the normal square behind you.");
    						trace = 3;
    					}
    					
    				}
    				else if(trace == 3)
    				{
    					
    					if(forwards == true)
    					{
    						System.out.println("You went to the normal square ahead of you.");
    						placement = 129;
    						trace = 3;
    					}
    					if(backwards == true)
    					{
    						placement = 131;
    						System.out.println("You went to the normal square behind you.");
    						trace = 4;
    					}
    				}
    	
    				break;
    				
                case 131:
      				
     				breath --;
     				if(mbatterythisturn == true)
     				{
     					mbatterythisturn = false;
     					battery --;
     					System.out.println("Your battery is now at "+battery+"%.");
     				}
     				else
     					mbatterythisturn = true;

         			System.out.println("You have "+breath+" air left.");
         			System.out.println("Behind you is an open block. In front of you is the exit.");
         			System.out.println("Will you go *forwards* or *backwards*?");
     				String input156 = Direction132check.nextLine();
     				
     				if(input156.equalsIgnoreCase("Forwards"))
     					forwards = true;
     				if(input156.equalsIgnoreCase("Backwards"))
     					backwards = true;
     					
     				if(forwards == true)
     				{
     					System.out.println("You went to the exit.");
     					placement = 132;
     				}
     				if(backwards == true)
     				{
     					placement = 130;
     					System.out.println("You went to the open block behind you.");
     					trace = 3;
     				}
     				
     				break;
    				
			}
			
			if(left == false && right == false && forwards == false && backwards == false)
			{
				System.out.println("You attempted to move but found yourself unable to. You lost air and battery!");
				breath = (byte) (breath - 2);
				battery --;
				System.out.println("You now have "+breath+" air remaining. You have "+battery+"% battery remaining.");
			}
			left = false;
			right = false;
			forwards = false;
			backwards = false;
			
            if(breath == 0)
            {
             System.out.println("You ran out of breath and suffocated.");
             System.out.println("As your life flashed by your eyes, you realised what your mistake was. If only there was a way to try again!");
             System.exit(0);
            }
            if(battery == 0)
            {
             System.out.println("Your flashlight battery ran out. You quickly found yourself lost and subsequently suffocated.");
             System.out.println("As your life flashed by your eyes, you realised what your mistake was. If only there was a way to try again!");
             System.exit(0);
            }
            
            System.out.println();
            
            if(placement == 132)
            	break;

        }
		
		//End of underwater stage
		//usable inputs: 5 - 15, 18 - 22, 24, 26 - 30
		
		System.out.println("You climbed out of the water through another hole in the roof.");
		System.out.println("You had "+battery+"% battery left in your flashlight.");
		System.out.println("You found another battery for your flashlight on the ground. Your BATTERY was fully replenished!");
		battery = 100;
		System.out.println("You took off your diving suit and walked onwards.");
		
		System.out.println("You continued on your journey into the cave.");
		
	}

}